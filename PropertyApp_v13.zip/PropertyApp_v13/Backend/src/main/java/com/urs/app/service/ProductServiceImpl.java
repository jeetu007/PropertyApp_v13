package com.urs.app.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.app.dao.ProductDAO;
import com.urs.app.dao.ProductImageDAO;
import com.urs.app.dao.UserDAO;
import com.urs.app.dto.ProductDTO;
import com.urs.app.model.User;

@Service("productService")
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDAO productDAO;

	@Autowired
	UserDAO userDAO;

	@Autowired
	ProductImageDAO productImageDao;

	public List<ProductDTO> getAllProduct(String username, String role, int numberOfRecords, int pageSize) {
		return productDAO.getAllProduct(username, role, numberOfRecords, pageSize);
	}

	public List<ProductDTO> searchProducts(String username, String role, String searchString, int numberOfRecords,
			int pageSize) {
		return productDAO.searchProducts(username, role, searchString, numberOfRecords, pageSize);
	}

	public List<ProductDTO> getAllProductByRadius(int radius, String latitude, String longitude) {
		return productDAO.getAllProductByRadius(radius, latitude, longitude);
	}

	public List<ProductDTO> searchProductByProductId(int productId) {

		return productDAO.searchProductByProductId(productId);
	}

	public List<ProductDTO> searchProductBySearchString(String searchString) {
		return productDAO.searchProductBySearchString(searchString);
	}

	public void registerProperty(List<ProductDTO> products, String currentUserName)
			throws SerialException, SQLException, IOException {
		User user = userDAO.findUserByUsername(currentUserName);
		productDAO.registerProduct(products, user);

	}

	public boolean deleteProducts(List<ProductDTO> products) {
		return productDAO.deleteProducts(products);
	}

	public boolean updateProduct(List<ProductDTO> uprod) {
		try {
			return productDAO.updateProduct(uprod);
		} catch (Exception e) {
			return false;
		}

	}

	public boolean deletePropertyImage(String imgurl) {
		return productImageDao.deletePropertyImage(imgurl);
	}

}
