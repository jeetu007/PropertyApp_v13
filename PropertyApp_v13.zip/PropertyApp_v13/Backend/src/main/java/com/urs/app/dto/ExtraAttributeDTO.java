package com.urs.app.dto;

import java.io.Serializable;
import java.util.Date;

import com.urs.app.model.Product;

public class ExtraAttributeDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int extraAttributeId;
	
	private String attributeName;
	
	private String attributeDisplayName;
	
	private String attributeValue;
	
	private Product product;
	
	private Date createdOn;
	
	private Date modifiedOn;

	public int getExtraAttributeId() {
		return extraAttributeId;
	}

	public void setExtraAttributeId(int extraAttributeId) {
		this.extraAttributeId = extraAttributeId;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeDisplayName() {
		return attributeDisplayName;
	}

	public void setAttributeDisplayName(String attributeDisplayName) {
		this.attributeDisplayName = attributeDisplayName;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
}
