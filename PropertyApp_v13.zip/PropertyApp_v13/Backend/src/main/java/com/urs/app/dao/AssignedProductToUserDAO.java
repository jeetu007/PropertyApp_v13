package com.urs.app.dao;

import java.util.List;

import com.urs.app.dto.AssignedProductToUserDTO;

public interface AssignedProductToUserDAO {

	List<AssignedProductToUserDTO> getAllProductAssignedToGivenId(int userId);
	void assignProductToUser(List<AssignedProductToUserDTO> assignedProductToUserDTO,int userId);
}
