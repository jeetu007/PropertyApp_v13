package com.urs.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.urs.app.dto.ProductDTO;
import com.urs.app.service.ProductService;

@RestController
public class ManagerRestController {

	@Autowired
	ProductService productService;
	
	int pageNo = 0;
	
	/*
	 * This method get the product search as per brand name or model name
	 * 
	 * @param brand name or model name
	 * 
	 * @return list of the matched product
	 */
	@RequestMapping(value = "/manager/allProduct/{username}/search/{searchString}/page/{pageNo}/{pageSize}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ProductDTO>> searchProducts(@PathVariable("username") String username,@PathVariable("searchString") String searchString,
			@PathVariable("pageNo") int sPageIndex, @PathVariable("pageSize") int pageSize) {

		
		if (sPageIndex == 0) {
			pageNo = 1;
		} else {
			pageNo = sPageIndex;
		}

		int numberOfRecords = (pageNo * pageSize) - pageSize;

		List<ProductDTO> products = productService.searchProducts(username, "manager", searchString, numberOfRecords, pageSize);

		if (products.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You many decide to return HttpStatus.NOT_FOUND
		}

		return new ResponseEntity<List<ProductDTO>>(products, HttpStatus.OK);

	}// searchProducts(-,-,-,-)
	
	/*
	 * -----------------Retrieve All Products-------------------------------
	 */
	@RequestMapping(value = "/manager/allProduct/{username}/page/{pageNo}/{pageSize}", method = RequestMethod.GET)
	public ResponseEntity<List<ProductDTO>> listAllProducts(@PathVariable("username") String username,@PathVariable("pageNo") int sPageIndex,
			@PathVariable("pageSize") int pageSize) {

		if (sPageIndex == 0) {
			pageNo = 1;
		} else {
			pageNo = sPageIndex;
		}

		int numberOfRecords = (pageNo * pageSize) - pageSize;

		List<ProductDTO> product = productService.getAllProduct(username, "manager", numberOfRecords, pageSize);
		if (product.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<ProductDTO>>(product, HttpStatus.OK);
	}// listAllProducts(-,-)

}
