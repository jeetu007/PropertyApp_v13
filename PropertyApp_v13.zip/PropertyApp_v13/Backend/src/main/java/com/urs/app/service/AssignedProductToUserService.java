package com.urs.app.service;

import java.util.List;

import com.urs.app.dto.AssignedProductToUserDTO;

public interface AssignedProductToUserService {

	List<AssignedProductToUserDTO> getAllProductAssignedToGivenId(int userId);
	void assignProductToUser(List<AssignedProductToUserDTO> assignedProductToUserDTO,int userId);
	
}
