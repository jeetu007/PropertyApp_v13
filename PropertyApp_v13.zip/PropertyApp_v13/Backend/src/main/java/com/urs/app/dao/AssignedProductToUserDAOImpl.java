package com.urs.app.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.app.dto.AssignedProductToUserDTO;
import com.urs.app.model.AssignedProductToUser;

@Repository("assignedProductToUser")
@Transactional
public class AssignedProductToUserDAOImpl extends AbstractDAO<Integer, AssignedProductToUser>
		implements AssignedProductToUserDAO {

	@Autowired
	private ModelMapper modelMapper;
	
	@SuppressWarnings("unchecked")
	public List<AssignedProductToUserDTO> getAllProductAssignedToGivenId(int userId) {
		
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("userId", userId));
		List<AssignedProductToUser> assignList = (List<AssignedProductToUser>) criteria.list();
	
		AssignedProductToUserDTO assignDTO;
		List<AssignedProductToUserDTO> assignDTOList = new ArrayList<AssignedProductToUserDTO>();
		
		for (AssignedProductToUser assign : assignList) {
			assignDTO = modelMapper.map(assign, AssignedProductToUserDTO.class);

			assignDTOList.add(assignDTO);
		}
		return assignDTOList;
	}

	public void assignProductToUser(List<AssignedProductToUserDTO> assignedProductToUserDTO, int userId) {
		
		Criteria criteria = createEntityCriteria();
		
		for(AssignedProductToUserDTO assignDTO : assignedProductToUserDTO) {
			
			Criterion crit = Restrictions.eq("userId", userId);
			Criterion crit1 = Restrictions.eq("productId", assignDTO.getProductId());			
			criteria.add(Restrictions.and(crit, crit1));
			
			AssignedProductToUser assignUser = (AssignedProductToUser) criteria.uniqueResult();
			
			if(assignUser == null){
				assignUser = modelMapper.map(assignDTO, AssignedProductToUser.class);
				assignUser.setModifiedOn(new Date());
				assignUser.setCreatedOn(new Date());
				persist(assignUser);
			} else {
				delete(assignUser);
				assignUser.setModifiedOn(new Date());
				assignUser.setCreatedOn(new Date());
				persist(assignUser);
			}			
			
		}//for
		
	}//assignProductToUser(-,-)

}
