package com.urs.app.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import com.urs.app.dto.ProductDTO;
import com.urs.app.model.Product;
import com.urs.app.model.User;

public interface ProductDAO {

	List<ProductDTO> getAllProductDetail();

	List<ProductDTO> getAllProduct(String username, String role, int numberOfRecords, int pageSize);

	List<ProductDTO> searchProducts(String username, String role, String searchString, int numberOfRecords,
			int pageSize);

	List<ProductDTO> getAllProductByRadius(int radius, String latitude, String longitude);

	List<ProductDTO> searchProductBySearchString(String searchString);

	List<ProductDTO> searchProductByProductId(int productId);

	public void registerProduct(List<ProductDTO> products, User currentUser)
			throws SerialException, SQLException, IOException;

	boolean deleteProducts(List<ProductDTO> products);

	public boolean updateProduct(List<ProductDTO> uprod);

	void deleteImageFromRedis(Product prop, String imgurl);
}
