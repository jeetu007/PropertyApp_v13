package com.urs.app.dao;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.app.model.ExtraAttribute;

@Repository("extraAttributeDAO")
@Transactional
public class ExtraAttributeDAOImpl extends AbstractDAO<Integer, ExtraAttribute> implements ExtraAttributeDAO {

	public void saveExtraAttribute(ExtraAttribute extraAttribute) {
		persist(extraAttribute);
	}

	public void deleteExtraAttribute(ExtraAttribute extraAttribute) {
		delete(extraAttribute);
	}

	public ExtraAttribute getExtraAttributeById(int attibuteId) {
	  return getByKey(attibuteId);
	   
	 }

	 public void updateExtraAttribute(ExtraAttribute existingAttribute) {
	  update(existingAttribute);
	 }

}
