package com.urs.app.dto;

import java.io.Serializable;
import java.util.Date;

public class AssignedProductToUserDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int assignedProductId;
	
	private int productId;
	
	private int userId;
	
	private Date createdOn;
	
	private Date modifiedOn;

	public int getAssignedProductId() {
		return assignedProductId;
	}

	public void setAssignedProductId(int assignedProductId) {
		this.assignedProductId = assignedProductId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
}
