package com.urs.app.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.sql.rowset.serial.SerialException;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.google.maps.DistanceMatrixApi;
import com.google.maps.GeoApiContext;
import com.google.maps.model.DistanceMatrix;
import com.google.maps.model.DistanceMatrixElement;
import com.google.maps.model.DistanceMatrixRow;
import com.google.maps.model.LatLng;
import com.urs.app.dto.AssignedProductToUserDTO;
import com.urs.app.dto.ProductDTO;
import com.urs.app.model.ExtraAttribute;
import com.urs.app.model.Product;
import com.urs.app.model.ProductImage;
import com.urs.app.model.User;

@Repository("productDAO")
@Transactional
@PropertySource(value = { "classpath:application.properties" })
public class ProductDAOImpl extends AbstractDAO<Integer, Product> implements ProductDAO {

	@Autowired
	private Environment environment;

	@Autowired
	AssignedProductToUserDAO assignedProductToUserDAO;

	@Autowired
	UserDAO userDAO;

	@Autowired
	ProductImageDAO productImageDAO;

	@Autowired
	ExtraAttributeDAO extraAttributeDAO;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	@Qualifier("transactionManager")
	protected PlatformTransactionManager txManager;

	private static final String PRODUCTKEY = "Product";
	private static final String SEARCHPRODUCTKEY = "searchProduct";

	private HashOperations<String, Integer, Product> hashOps;
	private HashOperations<String, String, List<Product>> hashOperations;

	@Autowired
	private RedisTemplate<String, Product> redisTemplate;

	public ProductDAOImpl(RedisTemplate<String, Product> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	@PostConstruct
	private void init() {

		redisTemplate.execute(new RedisCallback<Object>() {

			public Object doInRedis(RedisConnection connection) throws DataAccessException {
				redisTemplate.delete(PRODUCTKEY);
				redisTemplate.delete(SEARCHPRODUCTKEY);
				return null;
			}

		});

		hashOps = redisTemplate.opsForHash();
		hashOperations = redisTemplate.opsForHash();

		TransactionTemplate tmpl = new TransactionTemplate(txManager);
		tmpl.execute(new TransactionCallbackWithoutResult() {
			@SuppressWarnings({ "unused", "unchecked" })
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				Map<String, List<Product>> searchProdList = new TreeMap<String, List<Product>>();

				Criteria criteria = createEntityCriteria();
				List<Product> productList = (List<Product>) criteria.list();

				for (Product product : productList) {
					List<Product> prodList = new ArrayList<Product>();
					hashOps.put(PRODUCTKEY, product.getProductId(), product);
					// for brandname
					List<Product> currentBrandValue = searchProdList.get(product.getBrandName().toLowerCase());
					if (currentBrandValue == null) {
						currentBrandValue = new ArrayList<Product>();
						searchProdList.put(product.getBrandName().toLowerCase(), currentBrandValue);
					}
					currentBrandValue.add(product);

					// for modelname
					List<Product> currentModelValue = searchProdList.get(product.getModelName().toLowerCase());
					if (currentModelValue == null) {
						currentModelValue = new ArrayList<Product>();
						searchProdList.put(product.getModelName().toLowerCase(), currentModelValue);
					}
					currentModelValue.add(product);

					// for location tag
					List<Product> currentLocationValue = searchProdList.get(product.getLocationTag().toLowerCase());
					if (currentLocationValue == null) {
						currentLocationValue = new ArrayList<Product>();
						searchProdList.put(product.getLocationTag().toLowerCase(), currentLocationValue);
					}
					currentLocationValue.add(product);

				} // for
				hashOperations.putAll(SEARCHPRODUCTKEY, searchProdList);
			}// doInTransactionWithoutResult()

		});

	}// init()

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<ProductDTO> getAllProduct(String username, String role, int numberOfRecords, int pageSize) {

		List<Product> productList = new ArrayList<Product>();
		int totalNoOfProductRecords = 0;

		if (role.equalsIgnoreCase("superadmin") || role.equalsIgnoreCase("agent") || role.equalsIgnoreCase("user")) {

			Map<Integer, Product> mapProductListRedis = new TreeMap<Integer, Product>(hashOps.entries(PRODUCTKEY));

			List redisResult = new ArrayList(mapProductListRedis.values());

			// for pagination logic
			int endRecords = numberOfRecords + pageSize;

			if (endRecords > redisResult.size()) {
				endRecords = redisResult.size();
			}

			for (int i = numberOfRecords; i < endRecords; i++) {
				productList.add((Product) redisResult.get(i));
			}

			totalNoOfProductRecords = redisResult.size();

		} else {
			User user = userDAO.findUserByUsername(username);
			List<AssignedProductToUserDTO> assignList = assignedProductToUserDAO
					.getAllProductAssignedToGivenId(user.getUserId());
			List<Product> prodList = new ArrayList<Product>();
			int start = numberOfRecords;
			int end = start + pageSize;

			for (AssignedProductToUserDTO assignDTO : assignList) {
				Product product = (Product) hashOps.get(PRODUCTKEY, assignDTO.getProductId());
				prodList.add(product);
			}

			int cnt = 0;

			for (int i = start; i < end; i++) {
				if (cnt >= prodList.size()) {
					break;
				}
				Product product = prodList.get(i);
				productList.add(product);
				cnt++;
			}

			totalNoOfProductRecords = prodList.size();

		} // else

		List<ProductDTO> productDTOList = new ArrayList<ProductDTO>();
		ProductDTO productDTO;

		for (Product product : productList) {
			product.setTotalNoOfProductRecords(totalNoOfProductRecords);
			productDTO = modelMapper.map(product, ProductDTO.class);

			productDTOList.add(productDTO);
		}

		return productDTOList;
	}

	/*
	 * This method search the list of product in the db as per the searchString
	 * given
	 * 
	 * @param searchString
	 * 
	 * @param pageSize
	 * 
	 * @param noOfRecords
	 * 
	 * @return list of Product
	 */
	public List<ProductDTO> searchProducts(String username, String role, String searchString, int numberOfRecords,
			int pageSize) {

		List<Product> productList = new ArrayList<Product>();
		int totalNoOfProductRecords = 0;

		String pattern = "*" + searchString + "*";

		if (role.equalsIgnoreCase("superadmin") || role.equalsIgnoreCase("agent") || role.equalsIgnoreCase("user")) {

			Map<Integer, Product> mapProduct = new TreeMap<Integer, Product>();
			ScanOptions options = ScanOptions.scanOptions().match(pattern).count(1000).build();
			Cursor<Entry<String, List<Product>>> cursor = hashOperations.scan(SEARCHPRODUCTKEY, options);
			while (cursor.hasNext()) {
				Entry<String, List<Product>> entryList = cursor.next();
				List<Product> prodList = entryList.getValue();

				for (Product product : prodList) {
					mapProduct.put(product.getProductId(), product);
				}

			}
			List<Product> prodList = new ArrayList<Product>(mapProduct.values());

			totalNoOfProductRecords = prodList.size();

			int start = numberOfRecords;
			int end = start + pageSize;

			System.out.println(start + "," + numberOfRecords + "," + end);

			if (end >= prodList.size()) {
				end = prodList.size();
			}

			for (int i = start; i < end; i++) {
				productList.add(prodList.get(i));
			}

		} else {
			User user = userDAO.findUserByUsername(username);
			List<AssignedProductToUserDTO> assignList = assignedProductToUserDAO
					.getAllProductAssignedToGivenId(user.getUserId());
			List<Product> prodList = new ArrayList<Product>();
			int start = numberOfRecords;
			int end = start + pageSize;

			for (AssignedProductToUserDTO assignDTO : assignList) {

				Product product = (Product) hashOps.get(PRODUCTKEY, assignDTO.getProductId());

				if (product.getBrandName().toLowerCase().contains(searchString.toLowerCase())
						|| product.getModelName().toLowerCase().contains(searchString.toLowerCase())
						|| product.getLocationTag().toLowerCase().contains(searchString.toLowerCase())) {
					prodList.add(product);
				}

			}

			if (end >= prodList.size()) {
				end = prodList.size();
			}

			for (int i = start; i < end; i++) {

				Product product = prodList.get(i);
				productList.add(product);

			}

			totalNoOfProductRecords = prodList.size();
		}

		ProductDTO productDTO;

		List<ProductDTO> productDTOList = new ArrayList<ProductDTO>();

		for (Product product : productList) {
			product.setTotalNoOfProductRecords(totalNoOfProductRecords);
			productDTO = modelMapper.map(product, ProductDTO.class);

			productDTOList.add(productDTO);
		}

		return productDTOList;
	}// searchUsers(-,-,-)

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<ProductDTO> getAllProductByRadius(int radius, String latitude, String longitude) {

		Set<Product> productSet = new TreeSet<Product>();

		Map<Integer, Product> mapProductListRedis = new TreeMap<Integer, Product>(hashOps.entries(PRODUCTKEY));
		List redisResult = new ArrayList(mapProductListRedis.values());

		System.out.println("RedisRes - " + redisResult);
		List<Product> productList = new ArrayList<Product>();

		for (int i = 0; i < redisResult.size(); i++) {
			productList.add((Product) redisResult.get(i));
		}
		System.out.println("ProdList- " + productList);
		int distanceBetweenMapOriginToProduct = 0;

		for (Product prod : productList) {
			if (prod.getLatitude() == null || prod.getLongitude() == null) {
				System.out.println("Latitude or longitude not found...");
			} else {
				Double prodLat = Double.parseDouble(prod.getLatitude());
				Double prodLng = Double.parseDouble(prod.getLongitude());

				Double givenLat = Double.parseDouble(latitude);
				Double givenLng = Double.parseDouble(longitude);

				LatLng origin = new LatLng(givenLat, givenLng); // set the
																// origin of
																// the circle
				LatLng destination = new LatLng(prodLat, prodLng); // set the
																	// destination
																	// for the
																	// range

				GeoApiContext context = new GeoApiContext()
						.setApiKey(environment.getRequiredProperty("google.api_key"));

				try {

					DistanceMatrix distanceMatrix = DistanceMatrixApi.newRequest(context).origins(origin)
							.destinations(destination).await();

					if (distanceMatrix.rows.length > 0) {
						for (DistanceMatrixRow rows : distanceMatrix.rows) {
							for (DistanceMatrixElement element : rows.elements) {
								if (element.distance != null) {
									String kmOrM = null;
									String dist = element.distance.humanReadable;

									// String dist=element.distance.toString();
									String parts[] = dist.split(" ");

									kmOrM = parts[1];
									parts[0] = parts[0].replaceAll(",", "").trim();

									try {
										distanceBetweenMapOriginToProduct = Integer.parseInt(parts[0]);
									} catch (NumberFormatException ne) {

									} catch (Exception e) {

									}

									if (kmOrM.equals("km")) {
										distanceBetweenMapOriginToProduct = distanceBetweenMapOriginToProduct * 1000;
									} // inner-if

								} // outer-if
								else {

									distanceBetweenMapOriginToProduct = distance(givenLat, givenLng, prodLat, prodLng);
								} // else

							} // inner-for
						} // outer-for
					} // before-for-loop if

				} catch (Exception e) {
					e.printStackTrace();
				} // catch

				prod.setDistance(distanceBetweenMapOriginToProduct);

				if (radius >= distanceBetweenMapOriginToProduct) {
					productSet.add(prod);
				}
			}

		} // for

		List<ProductDTO> productDTOList = new ArrayList(productSet);

		return productDTOList;

	}// getAllProductByRadius(-,-,-)

	/*
	 * This routine calculates the distance between two points (given the
	 * latitude/longitude of those points). It is being used to calculate :
	 *
	 * Definitions : South latitudes are negative, East longitudes are positive,
	 * North latitudes are positive, West longitudes are negative
	 */
	public int distance(Double lat1, Double lon1, Double lat2, Double lon2) {
		/*
		 * :::::Haversine formula::::: R = earth�s radius (mean radius =
		 * 6,371km) difflat = lat2 - lat1 difflong = long2 - long1 a =
		 * sin�(difflat/2) + cos(lat1) x cos(lat2) x sin�(diflong/2) c = 2 x
		 * atan2(sqrt(a), sqrt(1-a)) d = R x c
		 */
		final int R = 6371; // AVERAGE_RADIUS_OF_EARTH_KM = 6371;
		Double latDistance = toRad(lat2 - lat1);
		Double lonDistance = toRad(lon2 - lon1);
		Double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
				+ Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
		Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		int distance = (int) (R * c);
		return distance * 1000;

	}// distance(-,-,-,-)

	// this method find the radian
	private static Double toRad(Double value) {
		return value * Math.PI / 180;
	}// toRad(-)

	/*
	 * search product by product id
	 */
	public List<ProductDTO> searchProductByProductId(int productId) {

		List<ProductDTO> productDTOList = new ArrayList<ProductDTO>();

		Product product = (Product) hashOps.get(PRODUCTKEY, productId);

		ProductDTO productDTO = modelMapper.map(product, ProductDTO.class);

		productDTOList.add(productDTO);

		return productDTOList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<ProductDTO> searchProductBySearchString(String searchString) {

		String pattern = "*" + searchString.toLowerCase() + "*";

		List<Product> productList = new ArrayList<Product>();

		int totalNoOfRecords = 0;

		try {

			ScanOptions options = ScanOptions.scanOptions().match(pattern).count(1000).build();

			Cursor<Entry<String, List<Product>>> cursor = hashOperations.scan(SEARCHPRODUCTKEY, options);

			Map<Integer, Product> mapProduct = new TreeMap<Integer, Product>();

			while (cursor.hasNext()) {
				Entry<String, List<Product>> entry = cursor.next();
				List<Product> prodList = entry.getValue();
				for (Product product : prodList) {
					mapProduct.put(product.getProductId(), product);
				}
			}

			List mapToList = new ArrayList(mapProduct.values());

			for (int i = 0; i < mapToList.size(); i++) {
				Product product = (Product) mapToList.get(i);
				productList.add(product);
			}

			ProductDTO productDTO;

			List<ProductDTO> productDTOList = new ArrayList<ProductDTO>();

			for (Product product : productList) {
				product.setTotalNoOfProductRecords(totalNoOfRecords);
				productDTO = modelMapper.map(product, ProductDTO.class);

				productDTOList.add(productDTO);
			}

			return productDTOList;

		} finally {
			System.out.println("finally product");
		}

	}

	public void registerProduct(List<ProductDTO> products, User currentUser)
			throws SerialException, SQLException, IOException {

		for (ProductDTO productDTO : products) {

			Product newProduct = new Product();
			List<String> imageUrlList = productDTO.getImageUrlList();
			System.out.println(imageUrlList);
			newProduct = modelMapper.map(productDTO, Product.class);
			newProduct.setCreatedOn(new Date());
			newProduct.setLastModifiedUser(currentUser);
			newProduct.setModifiedOn(new Date());

			List<ProductImage> productImageList = new ArrayList<ProductImage>();
			for (int i = 0; i < productDTO.getImageUrlList().size(); i++) {
				ProductImage productImage = new ProductImage();
				productImage.setCreatedOn(new Date());
				productImage.setModifiedOn(new Date());
				productImage.setImage(productDTO.getImageUrlList().get(i));
				productImage.setShortImage(productDTO.getShortImageUrlList().get(i));
				productImage.setProduct(newProduct);
				productImageList.add(productImage);
				try {
					productImageDAO.saveProductImage(productImage);
				} catch (Exception e) {
					System.out.println("Error in saving ProductImage -" + e.getMessage());
				}
			} // for loop to saving images

			newProduct.setImageList(productImageList);
			try {
				persist(newProduct);
				System.out.println(newProduct.getImageList().get(0).getImageId());
				hashOps.put(PRODUCTKEY, newProduct.getProductId(), newProduct);
				System.out.println(hashOps.entries(PRODUCTKEY).entrySet().iterator().next().getValue().getImageList());

				if (hashOperations.hasKey(SEARCHPRODUCTKEY, newProduct.getBrandName().toLowerCase())) {
					hashOperations.get(SEARCHPRODUCTKEY, newProduct.getBrandName().toLowerCase()).add(newProduct);
				} else {
					List<Product> prodList = new ArrayList<Product>();
					prodList.add(newProduct);
					hashOperations.put(SEARCHPRODUCTKEY, newProduct.getBrandName().toLowerCase(), prodList);
				}

				if (hashOperations.hasKey(SEARCHPRODUCTKEY, newProduct.getModelName().toLowerCase())) {
					hashOperations.get(SEARCHPRODUCTKEY, newProduct.getModelName().toLowerCase()).add(newProduct);
				} else {
					List<Product> prodList = new ArrayList<Product>();
					prodList.add(newProduct);
					hashOperations.put(SEARCHPRODUCTKEY, newProduct.getModelName().toLowerCase(), prodList);
				}

				if (hashOperations.hasKey(SEARCHPRODUCTKEY, newProduct.getLocationTag().toLowerCase())) {
					hashOperations.get(SEARCHPRODUCTKEY, newProduct.getLocationTag().toLowerCase()).add(newProduct);
				} else {
					List<Product> prodList = new ArrayList<Product>();
					prodList.add(newProduct);
					hashOperations.put(SEARCHPRODUCTKEY, newProduct.getLocationTag().toLowerCase(), prodList);
				}
			} catch (Exception e) {
				System.out.println("Error in saving Product -" + e.getMessage());
			}

			List<ExtraAttribute> attributes = productDTO.getExtraAttributeList();

			for (ExtraAttribute attribute : attributes) {
				attribute.setCreatedOn(new Date());
				attribute.setModifiedOn(new Date());
				attribute.setProduct(newProduct);
				try {
					extraAttributeDAO.saveExtraAttribute(attribute);
				} catch (Exception e) {
					System.out.println("Error in saving ExtraAttribute -" + e.getMessage());
				}
			}

		} // for loop to save the products

	}// registerProduct(-,-)

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<ProductDTO> getAllProductDetail() {

		List<Product> productList = new ArrayList<Product>();
		int totalNoOfProductRecords = 0;

		Map<Integer, Product> mapProductListRedis = new TreeMap<Integer, Product>(hashOps.entries(PRODUCTKEY));

		List redisResult = new ArrayList(mapProductListRedis.values());

		totalNoOfProductRecords = redisResult.size();

		if (!redisResult.isEmpty()) {

			for (int i = 0; i < totalNoOfProductRecords; i++) {
				productList.add((Product) redisResult.get(i));
			}

			List<ProductDTO> productDTOList = new ArrayList<ProductDTO>();
			ProductDTO productDTO;

			for (Product product : productList) {
				product.setTotalNoOfProductRecords(totalNoOfProductRecords);
				productDTO = modelMapper.map(product, ProductDTO.class);

				productDTOList.add(productDTO);
			}

			return productDTOList;
		} else {
			return null;
		}

	}// getAllProductDetail()

	public boolean deleteProducts(List<ProductDTO> products) {
		boolean isProductDeleted = false;
		List<ExtraAttribute> extraAttributeList = new ArrayList<ExtraAttribute>();
		List<ProductImage> productImageList = new ArrayList<ProductImage>();

		for (ProductDTO productDTO : products) {
			extraAttributeList = productDTO.getExtraAttributeList();
			productImageList = productDTO.getImageList();
			Product product = modelMapper.map(productDTO, Product.class);
			for (ExtraAttribute extraAttribute : extraAttributeList) {
				extraAttributeDAO.deleteExtraAttribute(extraAttribute);
			}
			for (ProductImage productImage : productImageList) {
				productImageDAO.deleteProductImage(productImage);
			}
			try {
				delete(product);
				if (hashOps.hasKey(PRODUCTKEY, product.getProductId())) {
					hashOps.delete(PRODUCTKEY, product.getProductId(), product);
				}
				if (hashOperations.hasKey(SEARCHPRODUCTKEY, product.getBrandName().toLowerCase())) {
					hashOperations.delete(SEARCHPRODUCTKEY, product.getBrandName().toLowerCase(), product);
				}
				if (hashOperations.hasKey(SEARCHPRODUCTKEY, product.getModelName().toLowerCase())) {
					hashOperations.delete(SEARCHPRODUCTKEY, product.getModelName().toLowerCase(), product);
				}
				if (hashOperations.hasKey(SEARCHPRODUCTKEY, product.getLocationTag().toLowerCase())) {
					hashOperations.delete(SEARCHPRODUCTKEY, product.getLocationTag().toLowerCase(), product);
				}
				isProductDeleted = true;
				System.out.println("Property deleted.");
			} catch (Exception e) {
				System.out.println("Property not deleted." + e);
				isProductDeleted = false;
			}
		}
		return isProductDeleted;
	}

	/**
	 * Author : Darshan Makwana This method for updating product.
	 * 
	 * @param :
	 *            List<ProductDTO>
	 * @Description : using getProductId, it'll get product and using model
	 *              mapper, it will convert dto to model converstion. and then
	 *              it'll update on DB as well as redis using product id.
	 */
	public boolean updateProduct(List<ProductDTO> uprod) {
		try {
			List<String> newOriginalImageUrls = new ArrayList<String>();
			List<String> newThumbnailImageUrls = new ArrayList<String>();
			List<ExtraAttribute> extraAttributeList = new ArrayList<ExtraAttribute>();

			List<ProductImage> newProductImages = new ArrayList<ProductImage>();

			for (ProductDTO propdto : uprod) {
				Product prop = getByKey(propdto.getProductId());

				prop.setBrandName(propdto.getBrandName());
				prop.setModelName(propdto.getModelName());
				prop.setRemark(propdto.getRemark());
				prop.setHeight(propdto.getHeight());
				prop.setCreatedOn(propdto.getCreatedOn());
				prop.setDistance(propdto.getDistance());
				prop.setLastModifiedUser(prop.getLastModifiedUser());
				prop.setLatitude(propdto.getLatitude());
				prop.setLongitude(propdto.getLocationTag());
				prop.setLongitude(propdto.getLongitude());
				prop.setPrice(propdto.getPrice());
				prop.setModifiedOn(new Date());

				newOriginalImageUrls = propdto.getImageUrlList();
				newThumbnailImageUrls = propdto.getShortImageUrlList();
				extraAttributeList = propdto.getExtraAttributeList();

				for (ExtraAttribute attribute : extraAttributeList) {
					ExtraAttribute existingAttribute = extraAttributeDAO
							.getExtraAttributeById(propdto.getExtraAttributeList().get(0).getExtraAttributeId());
					existingAttribute.setAttributeDisplayName(attribute.getAttributeDisplayName());
					existingAttribute.setAttributeName(attribute.getAttributeName());
					existingAttribute.setAttributeValue(attribute.getAttributeValue());
					existingAttribute.setModifiedOn(new Date());
					existingAttribute.setProduct(prop);
					extraAttributeDAO.updateExtraAttribute(existingAttribute);
				}

				for (int i = 0; i < newOriginalImageUrls.size(); i++) {
					ProductImage productimage = new ProductImage();
					productimage.setCreatedOn(new Date());
					productimage.setModifiedOn(new Date());
					productimage.setImage(newOriginalImageUrls.get(i));
					productimage.setShortImage(newThumbnailImageUrls.get(i));
					productimage.setProduct(prop);
					newProductImages.add(productimage);
					productImageDAO.saveProductImage(productimage);
				}

				prop.setImageList(newProductImages);

				update(prop);

				ProductDTO p = modelMapper.map(prop, ProductDTO.class);
				updateRedis(p, uprod.get(0).getPreviousimage());
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	private void updateRedis(ProductDTO pDTO, List<ProductImage> PreviousImage) {

		Product p = modelMapper.map(pDTO, Product.class);
		p.getImageList().addAll(PreviousImage);

		hashOps.put(PRODUCTKEY, p.getProductId(), p);

		// Brand Name
		if (hashOperations.hasKey(SEARCHPRODUCTKEY, p.getBrandName().toLowerCase())) {
			List<Product> prods = hashOperations.get(SEARCHPRODUCTKEY, p.getBrandName().toLowerCase());

			hashOperations.delete(SEARCHPRODUCTKEY, p.getBrandName().toLowerCase());

			List<ProductImage> addNewProductImageList = new ArrayList<ProductImage>();
			// ProductImage newProductImage = null;

			for (int i = 0; i < prods.size(); i++) {
				if (prods.get(i).getProductId() == p.getProductId()) {
					addNewProductImageList = prods.get(i).getImageList();
					prods.remove(prods.get(i));
				}
			}

			prods.add(p);
			hashOperations.put(SEARCHPRODUCTKEY, p.getBrandName().toLowerCase(), prods);

		} else {
			List<Product> prods = new ArrayList<Product>();
			prods.add(p);
			hashOperations.put(SEARCHPRODUCTKEY, p.getBrandName().toLowerCase(), prods);
		}

		// modelname
		if (hashOperations.hasKey(SEARCHPRODUCTKEY, p.getModelName().toLowerCase())) {
			List<Product> prods = hashOperations.get(SEARCHPRODUCTKEY, p.getModelName().toLowerCase());
			hashOperations.delete(SEARCHPRODUCTKEY, p.getModelName().toLowerCase());
			for (int i = 0; i < prods.size(); i++) {
				if (p.getProductId() == prods.get(i).getProductId()) {
					prods.remove(prods.get(i));
				}
			}
			prods.add(p);
			hashOperations.put(SEARCHPRODUCTKEY, p.getModelName().toLowerCase(), prods);
		} else {
			List<Product> prods = new ArrayList<Product>();
			prods.add(p);
			hashOperations.put(SEARCHPRODUCTKEY, p.getModelName().toLowerCase(), prods);
		}

		// location..
		if (hashOperations.hasKey(SEARCHPRODUCTKEY, p.getLocationTag().toLowerCase())) {
			List<Product> prods = hashOperations.get(SEARCHPRODUCTKEY, p.getLocationTag().toLowerCase());
			hashOperations.delete(SEARCHPRODUCTKEY, p.getLocationTag().toLowerCase());
			for (int i = 0; i < prods.size(); i++) {
				if (p.getProductId() == prods.get(i).getProductId()) {
					prods.remove(prods.get(i));
				}
			}
			prods.add(p);
			hashOperations.put(SEARCHPRODUCTKEY, p.getLocationTag().toLowerCase(), prods);
		} else {
			List<Product> prods = new ArrayList<Product>();
			prods.add(p);
			hashOperations.put(SEARCHPRODUCTKEY, p.getLocationTag().toLowerCase(), prods);
		}

	}// end updateProduct()

	public void deleteImageFromRedis(Product prop, String imgurl) {

		try {
			// for geting product from redis.
			Product prod = hashOps.get(PRODUCTKEY, prop.getProductId());

			// and right way delete product object using id.
			hashOps.delete(PRODUCTKEY, prop.getProductId());

			// for getting imagalist.
			List<ProductImage> productImageList = prod.getImageList();

			// iterate...
			for (Iterator<ProductImage> iterator = productImageList.iterator(); iterator.hasNext();) {

				ProductImage image = iterator.next();
				if (image.getImage().equals(imgurl)) {
					System.out.println("inside if condition,,,,,");
					iterator.remove();
				}
			}

			prod.setImageList(productImageList);
			// To store updated product into redis.
			hashOps.put(PRODUCTKEY, prod.getProductId(), prod);

			// this is for brand name.......
			if (hashOperations.hasKey(SEARCHPRODUCTKEY, prop.getBrandName().toLowerCase())) {
				List<Product> brandnamelist = hashOperations.get(SEARCHPRODUCTKEY, prop.getBrandName().toLowerCase());
				hashOperations.delete(SEARCHPRODUCTKEY, prop.getBrandName().toLowerCase());
				Product p = new Product();
				for (int i = 0; i < brandnamelist.size(); i++) {
					if (brandnamelist.get(i).getProductId() == prop.getProductId()) {
						List<ProductImage> productAsBrandNameList = brandnamelist.get(i).getImageList();
						p = brandnamelist.get(i);
						brandnamelist.remove(brandnamelist.get(i));
						for (Iterator<ProductImage> iterator = productAsBrandNameList.iterator(); iterator.hasNext();) {
							ProductImage image = iterator.next();
							if (image.getImage().equals(imgurl)) {
								System.out.println("inside if condition,,,,,");
								iterator.remove();
							}
						}
						p.setImageList(productAsBrandNameList);
					}
				}
				brandnamelist.add(p);
				hashOperations.put(SEARCHPRODUCTKEY, prop.getBrandName().toLowerCase(), brandnamelist);

			}

			// this is for model name.......
			if (hashOperations.hasKey(SEARCHPRODUCTKEY, prop.getModelName().toLowerCase())) {
				List<Product> modelnamelist = hashOperations.get(SEARCHPRODUCTKEY, prop.getModelName().toLowerCase());
				hashOperations.delete(SEARCHPRODUCTKEY, prop.getModelName().toLowerCase());
				Product p = new Product();
				for (int i = 0; i < modelnamelist.size(); i++) {
					if (modelnamelist.get(i).getProductId() == prop.getProductId()) {
						List<ProductImage> productAsModelNameList = modelnamelist.get(i).getImageList();
						p = modelnamelist.get(i);
						modelnamelist.remove(modelnamelist.get(i));
						for (Iterator<ProductImage> iterator = productAsModelNameList.iterator(); iterator.hasNext();) {
							ProductImage image = iterator.next();
							if (image.getImage().equals(imgurl)) {
								System.out.println("inside if condition,,,,,");
								iterator.remove();
							}
						}
						p.setImageList(productAsModelNameList);
					}
				}
				modelnamelist.add(p);
				hashOperations.put(SEARCHPRODUCTKEY, prop.getBrandName().toLowerCase(), modelnamelist);

			}

			// this is for locationtag name.......
			if (hashOperations.hasKey(SEARCHPRODUCTKEY, prop.getLocationTag().toLowerCase())) {
				List<Product> locationTaglist = hashOperations.get(SEARCHPRODUCTKEY,
						prop.getLocationTag().toLowerCase());
				hashOperations.delete(SEARCHPRODUCTKEY, prop.getLocationTag().toLowerCase());
				Product p = new Product();
				for (int i = 0; i < locationTaglist.size(); i++) {
					if (locationTaglist.get(i).getProductId() == prop.getProductId()) {
						List<ProductImage> productAsLocationTagList = locationTaglist.get(i).getImageList();
						p = locationTaglist.get(i);
						locationTaglist.remove(locationTaglist.get(i));
						for (Iterator<ProductImage> iterator = productAsLocationTagList.iterator(); iterator
								.hasNext();) {
							ProductImage image = iterator.next();
							if (image.getImage().equals(imgurl)) {
								System.out.println("inside if condition,,,,,");
								iterator.remove();
							}
						}
						p.setImageList(productAsLocationTagList);
					}
				}
				locationTaglist.add(p);
				hashOperations.put(SEARCHPRODUCTKEY, prop.getBrandName().toLowerCase(), locationTaglist);

			}

			System.out.println("product updated....");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}// class