package com.urs.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.app.dao.UserDAO;
import com.urs.app.dto.UserDTO;
import com.urs.app.model.User;

@Service("UserService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;

	public List<UserDTO> searchUsers(String searchString, int numberOfRecords, int pageSize) {
		return userDAO.searchUsers(searchString, numberOfRecords, pageSize);
	}

	public List<UserDTO> getUsers(int numberOfRecords, int pageSize) {
		return userDAO.getUsers(numberOfRecords, pageSize);
	}

	public void saveUsers(User User) {
		userDAO.saveUsers(User);
	}

	public void updateUsers(List<UserDTO> UserDTOList) {
		userDAO.updateUsers(UserDTOList);
	}

	public void deleteUsers(List<UserDTO> userDTOList) {
		userDAO.deleteUsers(userDTOList);
	}

	public User findUserByUsername(String username) {

		return userDAO.findUserByUsername(username);
	}

	public List<UserDTO> findAllUsers() {
		return userDAO.findAllUsers();
	}

}
