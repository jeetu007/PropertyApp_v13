package com.urs.app.service;

import java.util.List;

import com.urs.app.dto.UserDTO;
import com.urs.app.model.User;

public interface UserService {

	List<UserDTO> searchUsers(String searchString,int numberOfRecords,int pageSize);
	List<UserDTO> getUsers(int numberOfRecords,int pageSize);
	List<UserDTO> findAllUsers();
	User findUserByUsername(String username);
	void saveUsers(User User);
	void updateUsers(List<UserDTO> UserDTOList);
	void deleteUsers(List<UserDTO> UserDTOList);
	
}
