package com.urs.app.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;

import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * The persistent class for the grant_user database table.
 * 
 */
@Entity
@Table(name="extra_attribute")
@NamedQuery(name="ExtraAttribute.findAll", query="SELECT e FROM ExtraAttribute e")
public class ExtraAttribute extends JdkSerializationRedisSerializer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="extra_atrribute_id")
	private int extraAttributeId;
	
	@Column(name="attribute_name")
	private String attributeName;
	
	@Column(name="attribute_display_name")
	private String attributeDisplayName;
	
	@Column(name="attribute_value")
	private String attributeValue;
	
	@ManyToOne
	@JoinColumn(name = "product_id", referencedColumnName = "product_id")
	@JsonBackReference
	private Product product;
	
	@Column(name = "created_on")
	private Date createdOn;
	
	@Column(name = "modified_on")
	private Date modifiedOn;
	
	public ExtraAttribute() {
	}

	public int getExtraAttributeId() {
		return extraAttributeId;
	}

	public void setExtraAttributeId(int extraAttributeId) {
		this.extraAttributeId = extraAttributeId;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeDisplayName() {
		return attributeDisplayName;
	}

	public void setAttributeDisplayName(String attributeDisplayName) {
		this.attributeDisplayName = attributeDisplayName;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
}
