package com.urs.app.service;

import java.util.List;

import com.urs.app.dto.GrantUserDTO;

public interface GrantUserService {

	List<GrantUserDTO> getGrantUserDetail();
	List<GrantUserDTO> getGrantUsers(int numberOfRecords,int pageSize);
	List<GrantUserDTO> searchGrantUsers(String searchString,int numberOfRecords,int pageSize);
	void updateGrantUsers(int[] usersId,String operation);
	boolean saveGrantUsers(List<GrantUserDTO> grantUserDTOList);
	
}
