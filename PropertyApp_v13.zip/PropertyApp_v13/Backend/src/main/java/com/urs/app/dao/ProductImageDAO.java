package com.urs.app.dao;

import com.urs.app.model.ProductImage;

public interface ProductImageDAO {

	public void saveProductImage(ProductImage productImage);
	
	public void deleteProductImage(ProductImage image);
	
	//for delete image 
	 public boolean deletePropertyImage(String imgurl);
}
