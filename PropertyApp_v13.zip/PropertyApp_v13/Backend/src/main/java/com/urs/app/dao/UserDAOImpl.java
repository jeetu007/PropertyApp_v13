package com.urs.app.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.annotation.PostConstruct;

import org.hibernate.Criteria;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.urs.app.dto.UserDTO;
import com.urs.app.model.User;
import com.urs.app.model.UserProfile;

@Repository("UserDAO")
@Transactional
public class UserDAOImpl extends AbstractDAO<Integer, User> implements UserDAO {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private UserProfileDAO userProfileDAO;

	@Autowired
	@Qualifier("transactionManager")
	protected PlatformTransactionManager txManager;

	private static final String USERKEY = "User";
	private static final String SEARCHUSERKEY = "searchUser";

	@SuppressWarnings("rawtypes")
	private HashOperations hashOps;
	private HashOperations<String, String, User> hashOperations;

	@Autowired
	private RedisTemplate<String, User> redisTemplate;

	public UserDAOImpl(RedisTemplate<String, User> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	@PostConstruct
	private void init() {

		redisTemplate.execute(new RedisCallback<Object>() {

			public Object doInRedis(RedisConnection connection) throws DataAccessException {
				redisTemplate.delete(USERKEY);
				redisTemplate.delete(SEARCHUSERKEY);
				return null;
			}

		});

		hashOps = redisTemplate.opsForHash();
		hashOperations = redisTemplate.opsForHash();

		TransactionTemplate tmpl = new TransactionTemplate(txManager);
		tmpl.execute(new TransactionCallbackWithoutResult() {
			@SuppressWarnings("unchecked")
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				
				Criteria criteria = createEntityCriteria();
				List<User> userList = (List<User>) criteria.list();
				
				for (User user : userList) {
					hashOps.put(USERKEY, user.getUserId(), user);
					hashOperations.put(SEARCHUSERKEY, user.getUsername(), user);
					hashOperations.put(SEARCHUSERKEY, user.getEmail(), user);
				}

			}
		});

	}// init()

	/*
	 * This method search the list of user in the db as per the searchString
	 * given
	 * 
	 * @param searchString
	 * 
	 * @param pageSize
	 * 
	 * @param noOfRecords
	 * 
	 * @return list of user
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<UserDTO> searchUsers(String searchString, int numberOfRecords, int pageSize) {

		String pattern = "*" + searchString + "*";

		List<User> userList = new ArrayList<User>();
		
		try {
		
			ScanOptions options = ScanOptions.scanOptions().match(pattern).count(1000).build();
			
			Cursor<Entry<String, User>> cursor = hashOperations.scan(SEARCHUSERKEY, options);

			Map<Integer,User> mapUser = new TreeMap<Integer,User>();
			
			while(cursor.hasNext()) {
				Entry<String, User> euser = cursor.next();
				User user = euser.getValue();
				mapUser.put(user.getUserId(), user);
			}
			
			List mapToList = new ArrayList(mapUser.values());
			
			// for pagination logic
			int endRecords = numberOfRecords + pageSize;

			if (endRecords > mapToList.size()) {
				endRecords = mapToList.size();
			}
			
			for (int i = numberOfRecords; i < endRecords; i++) {
				User user = (User) mapToList.get(i);
				userList.add(user);				
			}

			UserDTO userDTO;

			List<UserDTO> userDTOList = new ArrayList<UserDTO>();

			for (User user : userList) {
				user.setTotalNoOfRecords(mapToList.size());
				userDTO = modelMapper.map(user, UserDTO.class);
				userDTOList.add(userDTO);
			}

			return userDTOList;

		} finally {
			System.out.println("finally happens");
		}

	}// searchUsers(-,-,-)

	/*
	 * This method get the list of user records from the db
	 * 
	 * @param pageSize
	 * 
	 * @param noOfRecords
	 * 
	 * @return list of user
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<UserDTO> getUsers(int numberOfRecords, int pageSize) {

		Map<Integer, User> mapUserListRedis = new TreeMap<Integer, User>(hashOps.entries(USERKEY));

		List redisResult = new ArrayList(mapUserListRedis.values());

		List<User> userList = new ArrayList<User>();

		// for pagination logic
		int endRecords = numberOfRecords + pageSize;

		if (endRecords > redisResult.size()) {
			endRecords = redisResult.size();
		}

		for (int i = numberOfRecords; i < endRecords; i++) {
			userList.add((User) redisResult.get(i));
		}

		int totalNoOfRecords = redisResult.size();

		UserDTO userDTO;
		List<UserDTO> userDTOList = new ArrayList<UserDTO>();

		for (User user : userList) {

			user.setTotalNoOfRecords(totalNoOfRecords);
			userDTO = modelMapper.map(user, UserDTO.class);
			userDTOList.add(userDTO);

		} // for()

		return userDTOList;

	}// getUsers(-,-)

	@SuppressWarnings("unchecked")
	public void saveUsers(User user) {

		user.setCreatedOn(new Date());
		user.setModifiedOn(new Date());
		persist(user);

		hashOps.put(USERKEY, user.getUserId(), user);
		hashOperations.put(SEARCHUSERKEY, user.getUsername(), user);
		hashOperations.put(SEARCHUSERKEY, user.getEmail(), user);

	}// saveUsers(-)

	/*
	 * This method update the user role
	 * 
	 * @param userList object
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void updateUsers(List<UserDTO> userDTOList) {

		for (UserDTO userDTO : userDTOList) {

			User user = modelMapper.map(userDTO, User.class);

			List<UserProfile> userprofile = userProfileDAO.findUserProfileByType(user.getUserProfiles());

			user.setUserProfiles(userprofile);
			user.setModifiedOn(new Date());

			update(user);

			hashOps.put(USERKEY, user.getUserId(), user);
			hashOperations.put(SEARCHUSERKEY, user.getUsername(), user);
			hashOperations.put(SEARCHUSERKEY, user.getEmail(), user);

		} // for

	}// updateUsers(-)

	/*
	 * This method delete the list of user record from db
	 * 
	 * @param userList object
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void deleteUsers(List<UserDTO> userDTOList) {

		for (UserDTO userDTO : userDTOList) {

			User user = modelMapper.map(userDTO, User.class);

			delete(user);

			hashOps.delete(USERKEY, user.getUserId());
			hashOperations.delete(SEARCHUSERKEY, user.getEmail());
			hashOperations.delete(SEARCHUSERKEY, user.getUsername());

		} // for()

	}// deleteUsers(-)

	/*
	 * find the user by username
	 */
	public User findUserByUsername(String username) {

		User user = hashOperations.get(SEARCHUSERKEY, username);

		return user;

	}// findByUserName()

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<UserDTO> findAllUsers() {

		Map<Integer, User> userMap = new TreeMap<Integer, User>(hashOps.entries(USERKEY));

		List<User> userList = new ArrayList(userMap.values());

		int totalNoOfRecords = userList.size();

		UserDTO userDTO;
		List<UserDTO> userDTOList = new ArrayList<UserDTO>();

		for (User user : userList) {
			user.setTotalNoOfRecords(totalNoOfRecords);
			userDTO = modelMapper.map(user, UserDTO.class);
			userDTOList.add(userDTO);

		} // for()

		return userDTOList;

	}// findAllUsers()

}
