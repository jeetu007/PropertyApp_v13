package com.urs.app.dao;

import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.app.model.Product;
import com.urs.app.model.ProductImage;

@Repository("productImageDAO")
@Transactional
public class ProductImageDAOImpl extends AbstractDAO<Integer, ProductImage> implements ProductImageDAO {

	@Autowired
	ProductDAO productDao;

	public void saveProductImage(ProductImage productImage) {
		persist(productImage);
	}

	public void deleteProductImage(ProductImage image) {
		delete(image);
	}

	/**
	 * Author : Darshan Makwana. This is for delete property image.
	 */
	public boolean deletePropertyImage(String imgurl) {
		try {
			System.out.println(imgurl);
			// find uniqe record...
			ProductImage imageData = (ProductImage) getSession().createCriteria(ProductImage.class)
					.add(Restrictions.eq("image", imgurl)).uniqueResult();
			System.out.println(imageData.getImage());
			Product prop = imageData.getProduct();
			List<ProductImage> imagelist = prop.getImageList();

			for (int i = 0; i < imagelist.size(); i++) {
				if (imagelist.get(i).getImage() == imageData.getImage()) {
					imagelist.remove(i);
					delete(imageData);
					break;
				}
			}

			productDao.deleteImageFromRedis(prop, imgurl);
			System.out.println("complete redis opertationasasa");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
