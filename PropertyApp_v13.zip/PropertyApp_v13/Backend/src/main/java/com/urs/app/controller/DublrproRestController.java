package com.urs.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.urs.app.dto.GrantUserDTO;
import com.urs.app.dto.ProductDTO;
import com.urs.app.service.AssignedProductToUserService;
import com.urs.app.service.GrantUserService;
import com.urs.app.service.ProductService;

@RestController
public class DublrproRestController {

	@Autowired
	TokenStore tokenStore;

	@Autowired
	AssignedProductToUserService assignedProductToUserService;

	@Autowired
	GrantUserService grantUserService;

	@Autowired
	ProductService productService;

	int pageNo = 0;

	/*
	 * Validate the incoming access token.
	 * @author - Premnath Christopher
	 */
	@RequestMapping(value = "/token/validateAccessToken", method = RequestMethod.POST)
	public ResponseEntity<Boolean> validateToken(HttpServletRequest request) {

		String accessToken = request.getHeader("access_token");
		OAuth2AccessToken oauth2AccessToken = tokenStore.readAccessToken(accessToken);

		if (oauth2AccessToken == null || oauth2AccessToken.equals(null)) {
			System.out.println("Token Not Found...");
			return new ResponseEntity<Boolean>(HttpStatus.NOT_FOUND);
		} else if (oauth2AccessToken.isExpired()) {
			System.out.println("Token Expired...");
			return new ResponseEntity<Boolean>(HttpStatus.IM_USED);
		} else {
			System.out.println("Token is alive...");
			System.out.println(oauth2AccessToken.getAdditionalInformation());
			return new ResponseEntity<Boolean>(HttpStatus.OK);
		}

	}//

	/*
	 * save new user
	 */
	@RequestMapping(value = "/guestUser/saveUsers", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<GrantUserDTO>> saveNewUsers(@RequestBody List<GrantUserDTO> grantUserDTOList) {
		boolean flag = grantUserService.saveGrantUsers(grantUserDTOList);

		if (flag == true) {
			return new ResponseEntity<List<GrantUserDTO>>(HttpStatus.OK);
		} else {
			return new ResponseEntity<List<GrantUserDTO>>(HttpStatus.NOT_MODIFIED);
		}

	}// saveNewUsers(-)

	/*
	 * This method will provide all grantUsers.
	 */
	@RequestMapping(value = "/guestUser/detail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<GrantUserDTO>> getGrantUser() {

		List<GrantUserDTO> grantUsers = grantUserService.getGrantUserDetail();
		if (grantUsers.isEmpty()) {
			return new ResponseEntity<List<GrantUserDTO>>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<List<GrantUserDTO>>(grantUsers, HttpStatus.OK);

	}// getGrantUser(-,-)

	/*
	 * ------------Retrieve All Products as per given radius-----------------
	 */
	@RequestMapping(value = "/guestUser/mapProduct/{radius}/{latitude}/{longitude}", method = RequestMethod.GET)
	public ResponseEntity<List<ProductDTO>> listAllProductsByRadius(@PathVariable("radius") int radius,
			@PathVariable("latitude") String latitude, @PathVariable("longitude") String longitude) {
		System.out.println(latitude + " ||" + longitude);
		List<ProductDTO> productDTOList = productService.getAllProductByRadius(radius, latitude, longitude);

		if (productDTOList.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You
																				// many
																				// decide
																				// to
																				// return
																				// HttpStatus.NOT_FOUND
		}

		return new ResponseEntity<List<ProductDTO>>(productDTOList, HttpStatus.OK);

	}// listAllProductsByRadius(-,-)

	/*
	 * ------------Search product as per given productId-----------------
	 */
	@RequestMapping(value = "/guestUser/product/search/{productId}", method = RequestMethod.GET)
	public ResponseEntity<List<ProductDTO>> getProductsByProductId(@PathVariable("productId") int productId) {

		List<ProductDTO> productDTOList = productService.searchProductByProductId(productId);

		if (productDTOList.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You
																				// many
																				// decide
																				// to
																				// return
																				// HttpStatus.NOT_FOUND
		}

		return new ResponseEntity<List<ProductDTO>>(productDTOList, HttpStatus.OK);

	}// getProductsByProductId(-)

	/*
	 * ------------Search product as per given productId-----------------
	 */
	@RequestMapping(value = "/guestUser/mapProduct/search/{searchString}", method = RequestMethod.GET)
	public ResponseEntity<List<ProductDTO>> findProductBySearchString(
			@PathVariable("searchString") String searchString) {

		List<ProductDTO> products = productService.searchProductBySearchString(searchString);

		if (products.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You
																				// many
																				// decide
																				// to
																				// return
																				// HttpStatus.NOT_FOUND
		}

		return new ResponseEntity<List<ProductDTO>>(products, HttpStatus.OK);

	}// listAllProductsByRadius(-,-)

	@RequestMapping(value = "/guestUser/logout", method = RequestMethod.POST, produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> userLogOut(
			/* HttpServletRequest request){ */@RequestParam("access_token") String accessToken) {

		// String accessToken = request.getHeader("access_token");

		String message = "";

		try {

			OAuth2AccessToken oauth2AccessToken = tokenStore.readAccessToken(accessToken);

			if (oauth2AccessToken == null || oauth2AccessToken.equals(null)) {
				return new ResponseEntity<String>("No such token exists !", HttpStatus.NOT_FOUND);
			}

			tokenStore.removeAccessToken(oauth2AccessToken);

			message = "You have been logged out.";
			System.out.println("You have been logged out.");

			return new ResponseEntity<String>(message, HttpStatus.OK);

		} catch (Exception e) {
			message = "Error in token store.";
			System.out.println("Error in token store.");
			return new ResponseEntity<String>(message, HttpStatus.NOT_ACCEPTABLE);
		}

	}// logout

	/* @auther vk kushwah */
	@RequestMapping(value = "isalive", method = RequestMethod.GET)
	public ResponseEntity<Map<String, Boolean>> isAlive() {
		Map<String, Boolean> map = new HashMap<String, Boolean>();
		map.put("isAlive", true);
		return new ResponseEntity<Map<String, Boolean>>(map, HttpStatus.OK);
	}

}// class
