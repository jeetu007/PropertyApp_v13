package com.urs.app.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;

import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * The persistent class for the app_user database table.
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "product")
@NamedQuery(name = "Product.findAll", query = "SELECT p FROM Product p")
public class Product extends JdkSerializationRedisSerializer implements Serializable,Comparable<Product>{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="product_id")
	private int productId;
	
	@Column(name="brand_name")
	private String brandName;
	
	@Column(name="model_name")
	private String modelName;
	
	@Column(name="location_tag")
	private String locationTag;
	
	@Column(name="price")
	private int price;
	
	@Column(name="width")
	private String width;
	
	@Column(name="height")
	private String height;
	
	@Column(name="latitude")
	private String latitude;
	
	@Column(name="longitude")
	private String longitude;
	
	@Transient
	private int distance;

	@Column(name="remark")
	private String remark;
	
	@Column(name = "created_on")
	private Date createdOn;
	
	@Column(name = "modified_on")
	private Date modifiedOn;
	
	@ManyToOne
	@JoinColumn(name = "last_modified_user", referencedColumnName = "user_id")
	private User lastModifiedUser;

	@OneToMany(mappedBy = "product", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Fetch(FetchMode.SUBSELECT)
	@JsonManagedReference
	private List<ExtraAttribute> extraAttributeList;
	
	@OneToMany(mappedBy = "product", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Fetch(FetchMode.SUBSELECT)
	@JsonManagedReference
	private List<ProductImage> imageList;
	
	@Transient
	private int totalNoOfProductRecords;

	public Product() {
		
	}
	
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getLocationTag() {
		return locationTag;
	}

	public void setLocationTag(String locationTag) {
		this.locationTag = locationTag;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public User getLastModifiedUser() {
		return lastModifiedUser;
	}

	public void setLastModifiedUser(User lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	public List<ExtraAttribute> getExtraAttributeList() {
		return extraAttributeList;
	}

	public void setExtraAttributeList(List<ExtraAttribute> extraAttributeList) {
		this.extraAttributeList = extraAttributeList;
	}

	public List<ProductImage> getImageList() {
		return imageList;
	}

	public int getTotalNoOfProductRecords() {
		return totalNoOfProductRecords;
	}

	public void setTotalNoOfProductRecords(int totalNoOfProductRecords) {
		this.totalNoOfProductRecords = totalNoOfProductRecords;
	}

	public void setImageList(List<ProductImage> imageList) {
		this.imageList = imageList;
	}

	public int compareTo(Product product) {
		
		if(distance > product.getDistance()) {
			return 1;
		} else if(distance < product.getDistance()) {
			return -1;
		} else {
			return 1;
		}
		
	}	//compareTo

}//class