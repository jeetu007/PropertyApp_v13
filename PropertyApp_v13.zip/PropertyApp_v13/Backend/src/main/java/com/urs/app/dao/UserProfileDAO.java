package com.urs.app.dao;

import java.util.List;

import com.urs.app.model.UserProfile;

public interface UserProfileDAO {

	List<UserProfile> findUserProfileByType(List<UserProfile> userProfileType);
	
}
