package com.urs.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.urs.app.dto.AssignedProductToUserDTO;
import com.urs.app.dto.GrantUserDTO;
import com.urs.app.dto.ProductDTO;
import com.urs.app.dto.UserDTO;
import com.urs.app.service.AssignedProductToUserService;
import com.urs.app.service.GrantUserService;
import com.urs.app.service.ProductService;
import com.urs.app.service.UserService;

@RestController
public class SuperAdminRestController {

	@Autowired
	UserService userService;
	
	@Autowired
	AssignedProductToUserService assignedProductToUserService;

	@Autowired
	GrantUserService grantUserService;
	
	@Autowired
	ProductService productService;

	int pageNo;	
	
	/*
	 * This method get the product search as per brand name or model name
	 * 
	 * @param brand name or model name
	 * 
	 * @return list of the matched product
	 */
	@RequestMapping(value = "/superadmin/allProduct/{username}/search/{searchString}/page/{pageNo}/{pageSize}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ProductDTO>> searchProducts(@PathVariable("username") String username,@PathVariable("searchString") String searchString,
			@PathVariable("pageNo") int sPageIndex, @PathVariable("pageSize") int pageSize) {

		
		if (sPageIndex == 0) {
			pageNo = 1;
		} else {
			pageNo = sPageIndex;
		}

		int numberOfRecords = (pageNo * pageSize) - pageSize;

		List<ProductDTO> products = productService.searchProducts(username, "superadmin", searchString, numberOfRecords, pageSize);

		if (products.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You many decide to return HttpStatus.NOT_FOUND
		}

		return new ResponseEntity<List<ProductDTO>>(products, HttpStatus.OK);

	}// searchProducts(-,-,-,-)
	
	/*
	 * -----------------Retrieve All Products-------------------------------
	 */
	@RequestMapping(value = "/superadmin/allProduct/{username}/page/{pageNo}/{pageSize}", method = RequestMethod.GET)
	public ResponseEntity<List<ProductDTO>> listAllProducts(@PathVariable("username") String username,@PathVariable("pageNo") int sPageIndex,
			@PathVariable("pageSize") int pageSize) {

		if (sPageIndex == 0) {
			pageNo = 1;
		} else {
			pageNo = sPageIndex;
		}

		int numberOfRecords = (pageNo * pageSize) - pageSize;

		List<ProductDTO> product = productService.getAllProduct(username, "superadmin", numberOfRecords, pageSize);
		if (product.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<ProductDTO>>(product, HttpStatus.OK);
	}// listAllProducts(-,-)
	
	/*
	 *	-----------------Retrieve All Users------------------------------- 
	 */
	@RequestMapping(value = "/allUsers", method = RequestMethod.GET)
    public ResponseEntity<List<UserDTO>> listAllUsers() {
        List<UserDTO> users = userService.findAllUsers();
        if(users.isEmpty()){
            return new ResponseEntity<List<UserDTO>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<UserDTO>>(users, HttpStatus.OK);
    }
	
	/*
	 * This method used to get the list of users
	 * 
	 * @param pageNo
	 * 
	 * @param pageSize
	 * 
	 * @return list of user detail
	 * 
	 */
	@RequestMapping(value = "/superadmin/users/page/{pageNo}/{pageSize}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UserDTO>> getUsers(@PathVariable("pageNo") int sPageIndex,
			@PathVariable("pageSize") int pageSize) {

		if (sPageIndex == 0) {
			pageNo = 1;
		} else {
			pageNo = sPageIndex;
		}

		int numberOfRecords = (pageNo * pageSize) - pageSize;

		List<UserDTO> users = userService.getUsers(numberOfRecords, pageSize);

		if (users.isEmpty()) {
			return new ResponseEntity<List<UserDTO>>(HttpStatus.NO_CONTENT);// You many decide to return HttpStatus.NOT_FOUND
		}

		return new ResponseEntity<List<UserDTO>>(users, HttpStatus.OK);

	}// getUsers(-,-)

	/*
	 * This method get the user search as per SSOID or email
	 * 
	 * @param sso_id or email
	 * 
	 * @return list of the matched user
	 */
	@RequestMapping(value = "/superadmin/users/search/{searchString}/page/{pageNo}/{pageSize}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UserDTO>> searchUsers(@PathVariable("searchString") String searchString,
			@PathVariable("pageNo") int sPageIndex, @PathVariable("pageSize") int pageSize) {

		
		if (sPageIndex == 0) {
			pageNo = 1;
		} else {
			pageNo = sPageIndex;
		}

		int numberOfRecords = (pageNo * pageSize) - pageSize;

		List<UserDTO> users = userService.searchUsers(searchString, numberOfRecords, pageSize);

		if (users.isEmpty()) {
			return new ResponseEntity<List<UserDTO>>(HttpStatus.NO_CONTENT);// You many decide to return HttpStatus.NOT_FOUND
		}

		return new ResponseEntity<List<UserDTO>>(users, HttpStatus.OK);

	}// searchUsers(-,-)

	/*
	 * This method delete the user
	 * 
	 * @RequestBody userList
	 * 
	 * @return success response
	 */
	@RequestMapping(value = "/superadmin/users/", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UserDTO>> deleteUsers(@RequestBody List<UserDTO> userList) {

		userService.deleteUsers(userList);

		return new ResponseEntity<List<UserDTO>>(HttpStatus.OK);
	}// deleteUsers(-,-)

	/*
	 * This method update the user role
	 * 
	 * @RequestBody userList object
	 * 
	 * @return success response
	 */
	@RequestMapping(value = "/superadmin/users/", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UserDTO>> updateUsers(@RequestBody List<UserDTO> userList) {
		userService.updateUsers(userList);
		return new ResponseEntity<List<UserDTO>>(HttpStatus.OK);
	}// updateUsers(-,-)

	/*
	 * This method will provide all grantUsers having pending status.
	 */
	@RequestMapping(value = "/superadmin/grantUsers/page/{pageNo}/{pageSize}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<GrantUserDTO>> getGrantUser(@PathVariable("pageNo") int pageNo,
			@PathVariable("pageSize") int pageSize) {

		int index;
		if (pageNo == 0) {
			index = 1;
		} else {
			index = pageNo;
		}

		int records = (index * pageSize) - pageSize;
		List<GrantUserDTO> grantUsers = grantUserService.getGrantUsers(records, pageSize);
		if (grantUsers.isEmpty()) {
			return new ResponseEntity<List<GrantUserDTO>>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<List<GrantUserDTO>>(grantUsers, HttpStatus.OK);

	}// getGrantUser(-,-)

	/*
	 * This method will provide list of grantUsers .
	 */
	@RequestMapping(value = "/superadmin/grantUsers/search/{searchString}/page/{pageNo}/{pageSize}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<GrantUserDTO>> searchGrantUser(@PathVariable("searchString") String searchString,
			@PathVariable("pageNo") int pageNo, @PathVariable("pageSize") int pageSize) {

		int index;
		if (pageNo == 0) {
			index = 1;
		} else {
			index = pageNo;
		}

		int records = (index * pageSize) - pageSize;
		List<GrantUserDTO> grantUsers = grantUserService.searchGrantUsers(searchString, records, pageSize);
		if (grantUsers.isEmpty()) {
			return new ResponseEntity<List<GrantUserDTO>>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<List<GrantUserDTO>>(grantUsers, HttpStatus.OK);

	}// searchGrantUser(searchString, pageNo,pageSize)

	/*
	 *
	 * This method will call service method for do action accept or deny .
	 */
	@RequestMapping(value = "/superadmin/grantUsers/{userId}/{operation}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateGrantUsers(@PathVariable("userId") int[] userId,
			@PathVariable("operation") String operation) {
		grantUserService.updateGrantUsers(userId, operation);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}// updateGrantUsers(-,-)

	/*
	 * This method assign the selected product to user
	 * 
	 * @param assignProductUser object List
	 * 
	 * @return success
	 */
	@RequestMapping(value = "/superadmin/assignProduct/{userId}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<AssignedProductToUserDTO>> assignProducts(@PathVariable("userId") int userId,
			@RequestBody List<AssignedProductToUserDTO> assignProductToUserDTOList) {
		assignedProductToUserService.assignProductToUser(assignProductToUserDTOList, userId);
		return new ResponseEntity<List<AssignedProductToUserDTO>>(HttpStatus.OK);
	}// assignProducts()
	
}// class UserController
