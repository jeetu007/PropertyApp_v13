package com.urs.app.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.urs.app.dto.ProductDTO;
import com.urs.app.service.ProductService;

@RestController
public class AgentController {

	@Autowired
	private ProductService productService;

	int pageNo = 0;

	/*
	 * This method save the new product
	 * 
	 * @param product Object
	 * 
	 * @return list of the product
	 */
	@RequestMapping(value = "/agent/products", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ProductDTO>> doProductRegistration(@RequestBody List<ProductDTO> products,
			@RequestParam("currentUsername") String currentUserName) throws IOException, SerialException, SQLException {

		System.out.println(currentUserName);

		productService.registerProperty(products, currentUserName);
		return new ResponseEntity<List<ProductDTO>>(products, HttpStatus.OK);
	}

	/*
	 * -----------------Retrieve All Products-------------------------------
	 */
	@RequestMapping(value = "/agent/allProduct/{username}/page/{pageNo}/{pageSize}", method = RequestMethod.GET)
	public ResponseEntity<List<ProductDTO>> listAllProducts(@PathVariable("username") String username,
			@PathVariable("pageNo") int sPageIndex, @PathVariable("pageSize") int pageSize) {

		if (sPageIndex == 0) {
			pageNo = 1;
		} else {
			pageNo = sPageIndex;
		}

		int numberOfRecords = (pageNo * pageSize) - pageSize;

		List<ProductDTO> product = productService.getAllProduct(username, "agent", numberOfRecords, pageSize);
		if (product.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You
																				// many
																				// decide
																				// to
																				// return
																				// HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<ProductDTO>>(product, HttpStatus.OK);
	}// listAllProducts(-,-)

	/*
	 * This method get the product search as per brand name or model name
	 * 
	 * @param brand name or model name
	 * 
	 * @return list of the matched product
	 */
	@RequestMapping(value = "/agent/allProduct/{username}/search/{searchString}/page/{pageNo}/{pageSize}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ProductDTO>> searchProducts(@PathVariable("username") String username,
			@PathVariable("searchString") String searchString, @PathVariable("pageNo") int sPageIndex,
			@PathVariable("pageSize") int pageSize) {

		if (sPageIndex == 0) {
			pageNo = 1;
		} else {
			pageNo = sPageIndex;
		}

		int numberOfRecords = (pageNo * pageSize) - pageSize;

		if (numberOfRecords == 0) {
			numberOfRecords = 1;
		}

		List<ProductDTO> products = productService.searchProducts(username, "agent", searchString, numberOfRecords,
				pageSize);

		if (products.isEmpty()) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NO_CONTENT);// You
																				// many
																				// decide
																				// to
																				// return
																				// HttpStatus.NOT_FOUND
		}

		return new ResponseEntity<List<ProductDTO>>(products, HttpStatus.OK);

	}// searchProducts(-,-,-,-)

	/**
	 * This method is used to delete one or more products.
	 * 
	 * @param products
	 * @return
	 * @author Premnath Christopher
	 */
	@RequestMapping(value = "agent/products/delete", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ProductDTO>> deleteProducts(@RequestBody List<ProductDTO> products) {
		boolean result = productService.deleteProducts(products);
		if (result) {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.OK);
		} else {
			return new ResponseEntity<List<ProductDTO>>(HttpStatus.NOT_IMPLEMENTED);
		}
	}

	/**
	 * Author: Darshan Makwana This is for updating product. it is true then it
	 * will return ok status, else not acceptable.
	 */
	@RequestMapping(value = "/agent/product/update", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> updateProduct(@RequestBody List<ProductDTO> uprod) {

		for (ProductDTO p : uprod) {
			System.out.println(p.getImageUrlList());
			System.out.println(p.getShortImageUrlList());
		}

		try {
			if (productService.updateProduct(uprod))
				return new ResponseEntity<Void>(HttpStatus.OK);
			else
				return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
		} catch (Exception e) {
			return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
		}

	}

	/**
	 * This method is used to delete the selected product image.
	 * @param imgurl
	 * @return
	 * 
	 * @author Darshan
	 */
	@RequestMapping(value = "/agent/product/image/delete", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> deleteProductImage(@RequestParam("imgurl") String imgurl) {
		System.out.println("delete controller");
		try {
			if (productService.deletePropertyImage(imgurl))
				return new ResponseEntity<Void>(HttpStatus.OK);
			else
				return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
		}
	}
}
