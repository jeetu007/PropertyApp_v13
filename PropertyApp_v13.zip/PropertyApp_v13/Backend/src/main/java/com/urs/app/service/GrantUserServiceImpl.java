package com.urs.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.app.dao.GrantUserDAO;
import com.urs.app.dto.GrantUserDTO;

@Service("grantUserService")
public class GrantUserServiceImpl implements GrantUserService {

	@Autowired
	GrantUserDAO grantUserDAO;
	
	public List<GrantUserDTO> getGrantUsers(int numberOfRecords, int pageSize) {
		return grantUserDAO.getGrantUsers(numberOfRecords, pageSize);
	}

	public List<GrantUserDTO> searchGrantUsers(String searchString, int numberOfRecords, int pageSize) {
		return grantUserDAO.searchGrantUsers(searchString, numberOfRecords, pageSize);
	}

	public void updateGrantUsers(int[] usersId, String operation) {
		grantUserDAO.updateGrantUsers(usersId, operation);
	}

	public boolean saveGrantUsers(List<GrantUserDTO> grantUserDTOList) {
		return grantUserDAO.saveGrantUsers(grantUserDTOList);
		
	}

	public List<GrantUserDTO> getGrantUserDetail() {
		
		return grantUserDAO.getGrantUserDetail();
	}

}
