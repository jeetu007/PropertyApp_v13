package com.urs.app.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.app.model.UserProfile;

@Repository("userProfileDAO")
@Transactional
public class UserProfileDAOImpl extends AbstractDAO<Integer, UserProfile> implements UserProfileDAO {

	public List<UserProfile> findUserProfileByType(List<UserProfile> userProfileType) {
		
		List<UserProfile> userProfileList = new ArrayList<UserProfile>();
		UserProfile userProfile;
		
		for(UserProfile us : userProfileType){
			
			userProfile = new UserProfile();
			Criteria criteria = createEntityCriteria();
			userProfile = (UserProfile) criteria.add(Restrictions.eq("type", us.getType())).uniqueResult();
			userProfileList.add(userProfile);
		}
		
		return userProfileList;
		
	}

}
