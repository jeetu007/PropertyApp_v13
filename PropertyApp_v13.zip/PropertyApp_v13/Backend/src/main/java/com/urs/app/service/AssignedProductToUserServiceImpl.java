package com.urs.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.app.dao.AssignedProductToUserDAO;
import com.urs.app.dto.AssignedProductToUserDTO;

@Service("AssignedProductToUserService")
public class AssignedProductToUserServiceImpl implements AssignedProductToUserService {

	@Autowired
	AssignedProductToUserDAO assignedProductToUserDAO;
	
	public List<AssignedProductToUserDTO> getAllProductAssignedToGivenId(int userId) {
		// TODO Auto-generated method stub
		return assignedProductToUserDAO.getAllProductAssignedToGivenId(userId);
	}

	public void assignProductToUser(List<AssignedProductToUserDTO> assignedProductToUserDTO, int userId) {
		// TODO Auto-generated method stub
		assignedProductToUserDAO.assignProductToUser(assignedProductToUserDTO, userId);
	}

}
