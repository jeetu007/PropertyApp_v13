package com.urs.app.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.urs.app.model.ExtraAttribute;
import com.urs.app.model.ProductImage;
import com.urs.app.model.User;

@SuppressWarnings("serial")
public class ProductDTO implements Serializable {

	private int productId;

	private String brandName;

	private String modelName;

	private String locationTag;

	private int price;

	private String width;

	private String height;

	private int distance;

	private String latitude;

	private String longitude;

	private String remark;

	private Date createdOn;

	private Date modifiedOn;

	private User lastModifiedUser;

	private List<ExtraAttribute> extraAttributeList;

	private List<ProductImage> imageList;

	private List<String> imageUrlList;

	private List<String> shortImageUrlList;

	private int totalNoOfProductRecords;

	private List<ProductImage> previousimage;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getLocationTag() {
		return locationTag;
	}

	public void setLocationTag(String locationTag) {
		this.locationTag = locationTag;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public User getLastModifiedUser() {
		return lastModifiedUser;
	}

	public void setLastModifiedUser(User lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	public List<ExtraAttribute> getExtraAttributeList() {
		return extraAttributeList;
	}

	public void setExtraAttributeList(List<ExtraAttribute> extraAttributeList) {
		this.extraAttributeList = extraAttributeList;
	}

	public List<ProductImage> getImageList() {
		return imageList;
	}

	public void setImageList(List<ProductImage> imageList) {
		this.imageList = imageList;
	}

	public List<String> getShortImageUrlList() {
		return shortImageUrlList;
	}

	public void setShortImageUrlList(List<String> shortImageUrlList) {
		this.shortImageUrlList = shortImageUrlList;
	}

	public int getTotalNoOfProductRecords() {
		return totalNoOfProductRecords;
	}

	public void setTotalNoOfProductRecords(int totalNoOfProductRecords) {
		this.totalNoOfProductRecords = totalNoOfProductRecords;
	}

	public List<String> getImageUrlList() {
		return imageUrlList;
	}

	public void setImageUrlList(List<String> imageUrlList) {
		this.imageUrlList = imageUrlList;
	}

	public List<ProductImage> getPreviousimage() {
		return previousimage;
	}

	public void setPreviousimage(List<ProductImage> previousimage) {
		this.previousimage = previousimage;
	}

}
