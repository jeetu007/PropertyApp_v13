package com.urs.app.dto;

import java.io.Serializable;
import java.util.Date;

import com.urs.app.model.Product;

@SuppressWarnings("serial")
public class ProductImageDTO implements Serializable{

	private int imageId;
	
	private String image;
	
	private String shortImage;
	
	private Product product;
	
	private Date createdOn;
	
	private Date modifiedOn;

	public int getImageId() {
		return imageId;
	}

	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getShortImage() {
		return shortImage;
	}

	public void setShortImage(String shortImage) {
		this.shortImage = shortImage;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
}
