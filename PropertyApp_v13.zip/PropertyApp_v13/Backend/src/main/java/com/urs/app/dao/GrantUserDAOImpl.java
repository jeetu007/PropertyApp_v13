package com.urs.app.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.app.dto.GrantUserDTO;
import com.urs.app.model.GrantUser;
import com.urs.app.model.User;
import com.urs.app.model.UserProfile;

@SuppressWarnings("deprecation")
@Repository("grantUserDAO")
@Transactional
public class GrantUserDAOImpl extends AbstractDAO<Integer, GrantUser> implements GrantUserDAO {

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	UserProfileDAO userProfileDAO;

	@Autowired
	UserDAO userDAO;

	/*
	 * This method search the list of user in the db as per the searchString
	 * provided having pending status
	 * 
	 * @param searchString
	 * 
	 * @param numberOfRecords
	 * 
	 * @param pageSize
	 * 
	 * @return list of user
	 */
	@SuppressWarnings({ "unchecked" })
	public List<GrantUserDTO> searchGrantUsers(String searchString, int numberOfRecords, int pageSize) {
		
		Criteria criteria = createEntityCriteria();

		Criterion crit = Restrictions.like("email", searchString, MatchMode.ANYWHERE);
		Criterion crit1 = Restrictions.like("username", searchString, MatchMode.ANYWHERE);
		Criterion crit2 = Restrictions.like("registrationStatus", "pending", MatchMode.ANYWHERE);

		criteria.add(Restrictions.or(crit, crit1));
		criteria.add(Restrictions.and(crit2));
		criteria.setFirstResult(numberOfRecords);
		criteria.setMaxResults(pageSize);

		List<GrantUser> grantUserList = (List<GrantUser>) criteria.list();
		
		int totalNoOfRecords = grantUserList.size();
	
		GrantUserDTO grantUserDTO;

		List<GrantUserDTO> grantUserDTOList = new ArrayList<GrantUserDTO>();

		for (GrantUser grantUser : grantUserList) {
			grantUser.setTotalNoOfGranstUserRecords(totalNoOfRecords);
			grantUserDTO = modelMapper.map(grantUser, GrantUserDTO.class);

			grantUserDTOList.add(grantUserDTO);
		}

		return grantUserDTOList;

	}// searchGrantUsers(-,-,-)

	/*
	 * (non-Javadoc)
	 * @see oauth2.security.dao.GrantUserDAO#updateGrantUsers(int[], java.lang.String)
	 * 
	 * this method update the grantUser
	 */
	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public void updateGrantUsers(int[] userId, String operation) {

		if (operation.equals("accept")) {
			Session session = getSession();
			for (int i = 0; i < userId.length; i++) {

				Criteria criteria = createEntityCriteria();
				Criterion cr1 = Restrictions.like("grantUserId", userId[i]);
				criteria.add(Restrictions.or(cr1));
				// Or Criteria Condition
				criteria.add(Restrictions.or(cr1));
				List<GrantUser> grantsUsers = (List<GrantUser>) criteria.list();
				saveUser(grantsUsers);
				Query query = session.createQuery(
						"update  GrantUser gu set registrationStatus='Approved'  where gu.grantUserId=" + userId[i]);
				query.executeUpdate();
			}
		}
		if (operation.equals("deny")) {
			for (int i = 0; i < userId.length; i++) {
				Session session = getSession();
				Query query = session.createQuery(
						"update  GrantUser gu set registrationStatus='rejected'  where gu.grantUserId=" + userId[i]);
				int count = query.executeUpdate();
				
			}
		}
	}// updateGrantUsers(-,-)

	/*
	 * this method save the grant User to User
	 */
	public void saveUser(List<GrantUser> grantUserList){
		
		List<UserProfile> userProfileList = new ArrayList<UserProfile>();
		UserProfile userProfile = new UserProfile();
		
		for(GrantUser grantUser : grantUserList){
			
			User newUser = new User();
			newUser.setAddress(grantUser.getAddress());
			newUser.setEmail(grantUser.getEmail());
			newUser.setFirstName(grantUser.getFirstName());
			newUser.setLastName(grantUser.getLastName());
			newUser.setMobile(grantUser.getMobile());
			newUser.setPassword(grantUser.getPassword());
			newUser.setUsername(grantUser.getUsername());
			newUser.setStatus("active");
			newUser.setCurrentLatitude(grantUser.getCurrentLatitude());
			newUser.setCurrentLongitude(grantUser.getCurrentLongitude());
			newUser.setImage(grantUser.getImage());
			userProfile.setType(grantUser.getRole());
			userProfileList.add(userProfile);
			List<UserProfile> userProfiles = userProfileDAO.findUserProfileByType(userProfileList);
			newUser.setUserProfiles(userProfiles);
			
			userDAO.saveUsers(newUser);
		}
		
	}//save(-)
	
	/*
	 * (non-Javadoc)
	 * @see oauth2.security.dao.GrantUserDAO#totalNoOfGrantUserRecords()
	 * 
	 * this method will the total no of records of grant User 
	 */
	@SuppressWarnings({ "unchecked", "static-access" })
	public int totalNoOfGrantUserRecords() {

		Criteria criteria = createEntityCriteria();
		criteria.setResultTransformer(criteria.DISTINCT_ROOT_ENTITY);
		List<GrantUser> grantUserList = (List<GrantUser>) criteria.list();

		int noOfGrantUserRecords = grantUserList.size();

		return noOfGrantUserRecords;
	}

	/*
	 * This method get the list of user in the db having pending status
	 * 
	 * @param searchString
	 * 
	 * @param numberOfRecords
	 * 
	 * @param pageSize
	 * 
	 * @return list of user
	 */
	@SuppressWarnings({ "static-access", "unchecked" })
	public List<GrantUserDTO> getGrantUsers(int numberOfRecords, int pageSize) {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.like("registrationStatus", "pending", MatchMode.ANYWHERE));
		criteria.setResultTransformer(criteria.DISTINCT_ROOT_ENTITY);

		List<GrantUser> grantUserList = (List<GrantUser>) criteria.list();
		int totalNoOfRecords = grantUserList.size();

		criteria.setFirstResult(numberOfRecords);
		criteria.setMaxResults(pageSize);

		grantUserList = (List<GrantUser>) criteria.list();

		GrantUserDTO grantUserDTO;

		List<GrantUserDTO> grantUserDTOList = new ArrayList<GrantUserDTO>();

		for (GrantUser grantUser : grantUserList) {
			grantUser.setTotalNoOfGranstUserRecords(totalNoOfRecords);
			grantUserDTO = modelMapper.map(grantUser, GrantUserDTO.class);

			grantUserDTOList.add(grantUserDTO);
		}

		return grantUserDTOList;
	}

	/*
	 * 
	 * (non-Javadoc)
	 * @see dublrpro.dao.GrantUserDAO#saveGrantUsers(java.util.List)
	 * 
	 * this method will save new grant user
	 * 
	 * @param list of grantUserDTO object
	 */
	@SuppressWarnings("unused")
	public boolean saveGrantUsers(List<GrantUserDTO> grantUserDTOList) {
		
		Criteria criteria = createEntityCriteria();
		boolean flag = false;
		
		for(GrantUserDTO grantUserDTO : grantUserDTOList) {
			
			GrantUser grantUser = modelMapper.map(grantUserDTO, GrantUser.class);
			
			grantUser.setRegistrationStatus("pending");
			grantUser.setStatus("inactive");
			grantUser.setCreatedOn(new Date());
			grantUser.setModifiedOn(new Date());
			
			try {
				persist(grantUser);
				
				flag = true;
				
			} catch(Exception e) {
				flag = false;
			}
			
		}
		
		return flag;
		
	}//saveGrantUsers(-)

	@SuppressWarnings("unchecked")
	public List<GrantUserDTO> getGrantUserDetail() {
		Criteria criteria = createEntityCriteria();
		List<GrantUser> grantUserList = (List<GrantUser>) criteria.list();
		int totalNoOfRecords = grantUserList.size();
		GrantUserDTO grantUserDTO;

		List<GrantUserDTO> grantUserDTOList = new ArrayList<GrantUserDTO>();

		for (GrantUser grantUser : grantUserList) {
			grantUser.setTotalNoOfGranstUserRecords(totalNoOfRecords);
			grantUserDTO = modelMapper.map(grantUser, GrantUserDTO.class);

			grantUserDTOList.add(grantUserDTO);
		}

		return grantUserDTOList;
	}

}
