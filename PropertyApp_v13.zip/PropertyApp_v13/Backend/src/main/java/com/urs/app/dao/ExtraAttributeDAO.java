package com.urs.app.dao;

import com.urs.app.model.ExtraAttribute;

public interface ExtraAttributeDAO {

	public void saveExtraAttribute(ExtraAttribute extraAttribute);
	
	public void deleteExtraAttribute(ExtraAttribute extraAttribute);

	public ExtraAttribute getExtraAttributeById(int extraAttributeId);

	public void updateExtraAttribute(ExtraAttribute existingAttribute);
}
