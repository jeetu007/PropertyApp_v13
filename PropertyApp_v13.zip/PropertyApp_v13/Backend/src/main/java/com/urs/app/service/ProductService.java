package com.urs.app.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import com.urs.app.dto.ProductDTO;

public interface ProductService {

	List<ProductDTO> getAllProduct(String username, String role, int numberOfRecords, int pageSize);

	List<ProductDTO> searchProducts(String username, String role, String searchString, int numberOfRecords,
			int pageSize);

	List<ProductDTO> getAllProductByRadius(int radius, String latitude, String longitude);

	List<ProductDTO> searchProductBySearchString(String searchString);

	List<ProductDTO> searchProductByProductId(int productId);

	void registerProperty(List<ProductDTO> products, String currentUserName)
			throws SerialException, SQLException, IOException;

	boolean deleteProducts(List<ProductDTO> products);

	// for delete image
	public boolean deletePropertyImage(String imgurl);

	boolean updateProduct(List<ProductDTO> uprod);
}
