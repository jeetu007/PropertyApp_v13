package com.urs.app.dao;

import java.util.List;

import com.urs.app.dto.UserDTO;
import com.urs.app.model.User;

public interface UserDAO {

	User findUserByUsername(String username);
	List<UserDTO> findAllUsers();
	List<UserDTO> searchUsers(String searchString,int numberOfRecords,int pageSize);
	List<UserDTO> getUsers(int numberOfRecords,int pageSize);
	void saveUsers(User User);
	void updateUsers(List<UserDTO> UserDTOList);
	void deleteUsers(List<UserDTO> UserDTOList);
	
}
