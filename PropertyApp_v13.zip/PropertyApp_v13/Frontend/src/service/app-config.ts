import { Injectable } from '@angular/core';

@Injectable()
export class AppConfig {

    public userTable = "app_user";
    public imageTable = "image";
    public propertyFolder = "property";
    public userFolder = "user";

    public baseImageUrl = 'https://storage.googleapis.com/image-video/';
    public imageLogo = "assets/img/logo.jpg";

    public isNetworkConnected : boolean = true;
    

    constructor() {
    }

    getUserTableName() {
        return this.userTable;
    }

    getImageTableName() {
        return this.imageTable;
    }

    getPropertyFolderName() {
        return this.propertyFolder;
    }

    getuserFolderName() {
        return this.userFolder;
    }

    getGoogleCouldImageUrl() {
        return this.baseImageUrl;
    }

    getDefaultImageLogo() {
        return this.imageLogo;
    }

    updateNetworkConnection(condition :boolean){
        this.isNetworkConnected = condition;
    }

    checkNetworkConnection() : boolean {
        return this.isNetworkConnected;
    }



}