import { Injectable } from '@angular/core';
import { Http, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { BackgroundMode } from '@ionic-native/background-mode';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { File, FileEntry } from '@ionic-native/file';
import { Platform } from 'ionic-angular';
import { Events } from 'ionic-angular';
import { AppConfig } from '../service/app-config';



@Injectable()
export class BackgroundServices {

    public baseUrl = 'http://192.168.2.209:8081/PropertyApp_v2/';
    public googleCloudUrl = 'https://www.googleapis.com/upload/storage/v1/b/image-video/o';

    public interval: any;
    public sql: SQLiteObject;
    public totalImages: any = 0;
    public currentImage: any = 0;
    public backgroundProcessRunning: boolean = false;
    public backgroundProcessInterval: number = 5000;

    public attemptCounter: number = 0;

    public notificationTitle: string = 'URS System App';
    public notificationText: string = 'Active in background..';

    public userTable :any;
    public imageTable : any;

    constructor(platform: Platform, public http: Http, public backgroundMode: BackgroundMode,private appConfig : AppConfig,
         public sqlite: SQLite, public file: File, public events: Events) {
             
        this.userTable = this.appConfig.getUserTableName();
        this.imageTable = this.appConfig.getImageTableName();
        
        platform.ready().then((res) => {
            this.backgroundMode.on('enable').subscribe((data) => {

                this.backgroundMode.disableWebViewOptimizations();

                this.sqlite.create({ name: 'data.db', location: 'default' })
                    .then((db: SQLiteObject) => {
                        this.sql = db;
                    }).catch(e => console.log(JSON.stringify(e)));

                this.backgroundMode.setDefaults({
                    title: this.notificationTitle,
                    text: this.notificationText,
                    color: '4db554'
                });

                this.events.subscribe('upload', (action) => {
                    this.attemptCounter = 0;
                    this.backgroundProcessRunning = false;

                    if ('upload' == action) {
                        this.interval = Observable.interval(this.backgroundProcessInterval).subscribe(x => {
                            if (!this.backgroundProcessRunning) {
                                this.backgroundProcess();
                            }
                        });
                    } else {
                        this.updateRecordsStatus("failed", "pending", true);
                    }

                });

            }, (error) => {
                console.log("Something is wrong !! " + JSON.stringify(error));
            });


        }).catch((err) => {
            console.log("backgroundServiceErr--" + err);
        });

    }

  
    backgroundProcess() {
        if (!this.backgroundProcessRunning) {
            this.backgroundProcessRunning = true;
            this.http.get(this.baseUrl + 'isalive').subscribe(
                response => {
                    if (response.json().isAlive) {
                        if (this.sql != undefined) {
                            this.sql.executeSql("select * from "+this.imageTable+" WHERE status = 'pending'", {})
                                .then((data) => {
                                    if (data.rows.length > 0) {
                                        this.attemptCounter++;
                                        this.totalImages = data.rows.length;
                                        this.currentImage = data.rows.length;
                                        this.backgroundMode.configure({ text: "Total Images To Be Uploaded : " + this.totalImages });

                                        if (this.attemptCounter <= 3) {
                                            this.googleUploading(data.rows, data.rows.length - 1);
                                        } else {
                                            this.backgroundProcessRunning = false;
                                            if (this.interval != undefined) {
                                                this.interval.unsubscribe();
                                            }
                                            this.attemptCounter = 0;
                                            this.updateRecordsStatus("pending", "failed", false);
                                        }

                                    } else {
                                        console.log("No record in the table !!");
                                        this.backgroundProcessRunning = false;
                                        if (this.interval != undefined) {
                                            this.interval.unsubscribe();
                                        }

                                    }
                                }).catch((e) => {
                                    console.log(JSON.stringify(e));
                                    this.backgroundProcessRunning = false;
                                });

                        }
                    } else {
                        this.backgroundProcessRunning = false;
                    }
                }, error => {
                    //check internet 
                    console.log(JSON.stringify(error));
                    this.backgroundProcessRunning = false;
                    this.attemptCounter++;
                    if (this.attemptCounter > 3) {
                        if (this.interval != undefined) {
                            this.interval.unsubscribe();
                        }
                        this.attemptCounter = 0;
                        this.updateRecordsStatus("pending", "failed", false);
                    }
                }
            );

        }
    }

    googleUploading(images, index) {
        if (index < 0) {
            this.backgroundMode.configure({ text: "All Images Uploaded Successfully" });
            this.backgroundProcessRunning = false;
            return null;
        }

        this.file.resolveLocalFilesystemUrl(images.item(index).path)
            .then(entry => (<FileEntry>entry).file(file => {

                let reader = new FileReader();
                reader.onloadend = () => {
                    let imageBlob = new Blob([reader.result], { type: file.type });
                    console.log("imageBlob : " + imageBlob.size);
                    let params: URLSearchParams = new URLSearchParams();
                    params.set('uploadType', 'media');
                    params.set('name', images.item(index).name);
                    let options = new RequestOptions({ params: params });
                    this.http.post(this.googleCloudUrl, imageBlob, options)
                        .subscribe(response => {
                            this.currentImage--;
                            this.backgroundMode.configure({ text: "Images Are Uploaded : " + (this.totalImages - this.currentImage) + " / " + this.totalImages });
                            console.log("Image file has been uploaded successfully");

                            if (this.sql != undefined) {
                                this.sql.executeSql("UPDATE "+this.imageTable+" SET status = 'done' WHERE name = '" + images.item(index).name + "'", {})
                                    .then((data) => {
                                        console.log("Record updated successfully !!");
                                        this.googleUploading(images, index - 1);
                                    }).catch(e => { console.log("error - " + JSON.stringify(e)); this.backgroundProcessRunning = false; });
                            }

                        }, error => {
                            try {
                                if (error.json().error && error.json().error.code == 401) {
                                    this.currentImage--;
                                    if (this.sql != undefined) {
                                        this.sql.executeSql("UPDATE "+this.imageTable+" SET status = 'done' WHERE name = '" + images.item(index).name + "'", {})
                                            .then((data) => {
                                                console.log("Record updated successfully !!");
                                                this.googleUploading(images, index - 1);
                                            }).catch(e => { console.log("error - " + JSON.stringify(e)); this.backgroundProcessRunning = false; });
                                    }
                                } else {
                                    this.backgroundProcessRunning = false;
                                }
                            } catch (err) {
                                console.log(err);
                                this.backgroundProcessRunning = false;
                            }
                            console.log("Error : " + JSON.stringify(error.json()));
                        });
                };

                reader.onerror = () => {
                    this.backgroundProcessRunning = false;
                    console.log("Sorry!, File reading error !!");
                };

                reader.readAsArrayBuffer(file);

            })).catch(err => { console.log(err); this.backgroundProcessRunning = false; });

    }

    updateRecordsStatus(oldStatus, newStatus, action) {
        if (this.sql != undefined) {
            this.sql.executeSql("UPDATE "+this.imageTable+" SET status = '" + newStatus + "' WHERE status = '" + oldStatus + "'", {})
                .then((data) => {
                    console.log("All Records updated successfully !!");
                    if (action)
                        this.events.publish('upload', 'upload');
                }).catch(e => { console.log("error - " + JSON.stringify(e)); });
        }
    }

}