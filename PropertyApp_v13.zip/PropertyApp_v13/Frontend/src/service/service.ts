import { Injectable } from '@angular/core';
import { Http, URLSearchParams, Response, RequestOptions, Headers } from '@angular/http';
import { LoadingController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { AppConfig } from '../service/app-config';

import { Observable } from 'rxjs/Rx';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';


@Injectable()
export class DataService {

    public circleRadius: any = 10000;
    public property;
    public propertiesForMap: any;
    public result: any;

    public clientId = 'my-trusted-client';
    public clientSecret = 'secret';
    public baseUrl = 'http://192.168.2.209:8081/PropertyApp_v2/'; // This is the base url of the backend service.

    public googleCloudUrl = 'https://www.googleapis.com/upload/storage/v1/b/image-video/o';

    PropertyFormData: FormData;
    public Registrationloader: any;
    public loggedInUser: any;
    public userTable : any;
    public imageTable : any;
    

    constructor(public http: Http, public loading: LoadingController,
        private toastCtrl: ToastController, private sqlite: SQLite, private appConfig : AppConfig) {
        this.PropertyFormData = new FormData();
        this.userTable = this.appConfig.getUserTableName();
    }

    /**
    * Darshan 
    */


    //delete
    doDeleteProductImage(imgulr: string, token): Observable<any> {

        let headers: Headers = new Headers();
        headers.append("Authorization", "Basic " + btoa(this.clientId + ":" + this.clientSecret));

        let params: URLSearchParams = new URLSearchParams();
        params.set('access_token', token);
        params.set('imgurl', imgulr);

        let options = new RequestOptions({ headers: headers, params: params });
        return this.http.delete(this.baseUrl + 'agent/product/image/delete', options)
            .map(this.handleResponse)
            .catch(this.handleError);
    }

    //update
    doUpdatePropertyData(propertydata: any, token): Observable<any> {

        // let headers: Headers = new Headers();
        // headers.append("Authorization", "Basic " + btoa(this.clientId + ":" + this.clientSecret));

        let params: URLSearchParams = new URLSearchParams();
        params.set('access_token', token);

        let options = new RequestOptions({ params: params });
        return this.http.put(this.baseUrl + 'agent/product/update', propertydata, options)
            .map(this.handleResponse)
            .catch(this.handleError);
    }



    /**This method is used to get the current logged in user.  */
    getCurrentUser(): any {
        this.loggedInUser = null;
        return new Promise((resolve, reject) => {
            this.sqlite.create({ name: 'data.db', location: 'default' })
                .then((db: SQLiteObject) => {
                    db.executeSql('select * from '+this.userTable, {})
                        .then((data) => {
                            if (data.rows.length > 0) {
                                this.loggedInUser = data.rows.item(data.rows.length - 1);
                                resolve(this.loggedInUser);
                            } else {
                                reject(this.loggedInUser);
                            }
                        }).catch(e => reject(e));
                }).catch(e => reject(e));
        });
    }

    setCurrentUser(userData, username) {
        console.log("SetCurrentUser" + JSON.stringify(userData));
        this.sqlite.create({
            name: 'data.db',
            location: 'default'
        })
            .then((db: SQLiteObject) => {
                db.executeSql('INSERT INTO '+this.userTable+' (access_token,authorities,expires_in,refresh_token,scope,token_type,user,username) VALUES(?,?,?,?,?,?,?,?)',
                    [userData.access_token, userData.authorities, userData.expires_in, userData.refresh_token, userData.scope, userData.token_type, userData.user, username])
                    .then(() => console.log('Set Current User -Data Inserted.'))
                    .catch(e => console.log('Error- ' + e));
            })
            .catch(e => console.log("sql lite error." + e));
    }

    /**
     * Darshan 
     */

    presentToast(mesg) {
        let toast = this.toastCtrl.create({
            message: mesg,
            duration: 3000,
            position: 'top'
        });
        toast.present();
    }

    
    /**
     * This is for register property data.
     * @param propertyData : contain propery data.
     * @param imageBlobList : contain list of capture images as blob for uploading cloud storage.
     * @param PropertyCloudImageUrlList : contain list of cloud storage image urls.
     * @param thumbnilBlobList : contain list of sort images as blob for uploading cloud storage.
     * @param PropertyCloudThumbnilUrlList : contain list of cloud storage sort image urls.
     * @param access_token 
     * @param currentUsername : current user. 
     */
    doRegistration(propertyData, imageBlobList, PropertyCloudImageUrlList,
        thumbnilBlobList, PropertyCloudThumbnilUrlList,
        access_token, currentUsername): any {

        this.Registrationloader = this.loading.create({
            content: 'Please wait...',
        });
        this.Registrationloader.present().then(() => {
            //This is for appending data proeprtyData object.
            this.PropertyFormData.append('propertyData', new Blob([JSON.stringify(propertyData)], { type: "application/json" }));
            for (let i = 0; i < imageBlobList.length; i++) {
                // ImageBlobList contains multiple images as blob image.
                // This is for appending blob image, and imageCloudUrl into propertyFormdata one by one. 
                this.PropertyFormData.append('propertyImage', imageBlobList[i], PropertyCloudImageUrlList[i].name);
                //uploading iamges on google cloud
                this.doUploadOnGoogleCloud(imageBlobList[i], PropertyCloudImageUrlList[i])
                    .subscribe(response => { console.log(JSON.stringify(response)) }
                    , error => { console.log(JSON.stringify(error)) });
            }
            for (let i = 0; i < thumbnilBlobList.length; i++) {
                // thumbnilBlobList contains multiple images as blob image.
                // This is for appending blob image, and thumbnailCloudUrl into propertyFormdata one by one. 
                this.PropertyFormData.append('propertyShortImage', thumbnilBlobList[i], PropertyCloudThumbnilUrlList[i]);
                //uploading iamges on google cloud
                this.doUploadOnGoogleCloud(thumbnilBlobList[i], PropertyCloudThumbnilUrlList[i])
                    .subscribe(response => { console.log(JSON.stringify(response)) }
                    , error => { console.log(JSON.stringify(error)) });

                if (i === thumbnilBlobList.length - 1) {
                    //calling registerPeroperty method for register property data into DB.
                    //params: propertyFormdata, accessToken, currentUsername.
                    this.registerProperty(this.PropertyFormData, access_token, currentUsername);
                }

            }
        });
        return new Promise((resolve, reject) => {
            resolve({ 1: "qqq", "aaa": "aaa" });
        });
    }//doRegistration(-,-,-,-,-,-,-)



    registerProperty(formData, access_token, currentUsername) {
        this.doPropertyRegistration(formData, access_token, currentUsername)
            .subscribe(
            response => {
                this.Registrationloader.dismiss();
                this.presentToast("Property record registered successfully !!");

            },
            error => {
                this.Registrationloader.dismiss();
                this.presentToast("Sorry !!, Property record not registered successfully");

            }
            );
    }

    /************************* */

    /**Prem**/

    doLogin(username, password): Observable<any> {
        let headers: Headers = new Headers();
        headers.append("Authorization", "Basic " + btoa(this.clientId + ":" + this.clientSecret));

        let params: URLSearchParams = new URLSearchParams();
        params.set('grant_type', 'password');
        params.set('username', username);
        params.set('password', password);

        let options = new RequestOptions({ headers: headers, params: params });

        return this.http.post(this.baseUrl + 'oauth/token', {}, options).map(this.handleData)
            .catch(this.handleError);
    }

    validateRefreshToken(refresh_token): Observable<any> {
        let headers: Headers = new Headers();
        headers.append("Authorization", "Basic " + btoa(this.clientId + ":" + this.clientSecret));

        let params: URLSearchParams = new URLSearchParams();
        params.set('grant_type', 'refresh_token');
        params.set('refresh_token', refresh_token);

        let options = new RequestOptions({ headers: headers, params: params });

        return this.http.post(this.baseUrl + 'oauth/token', {}, options).map(this.handleData)
            .catch(this.handleError);
    }

    doUserRegistration(userData: any): Observable<any> {
        console.log(userData);
        return this.http.post(this.baseUrl + 'guestUser/saveUsers', userData).map(this.handleResponse)
            .catch(this.handleError);
    }

    doPropertyRegistration(formData: any, access_token, currentUsername): Observable<any> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('access_token', access_token);
        params.set('currentUsername', currentUsername);
        let options: RequestOptions = new RequestOptions({ params: params });
        return this.http.post(this.baseUrl + 'agent/products', formData, options).map(this.handleData)
            .catch(this.handleError);
    }


    // current loggedin user is also hard coded for the time being.
    getProperties(access_token: string, userRole: string, currentUserName: any, currentLatitude: any, currentLongtitude: any, pageNo: number, pageSize: number): Observable<any> {
        console.log(currentLatitude + "..." + currentLongtitude);
        let params: URLSearchParams = new URLSearchParams();
        params.set('access_token', access_token);
        let options: RequestOptions = new RequestOptions({ params: params });

        if (userRole == "" || userRole == undefined) {
            return this.http.get(this.baseUrl + 'guestUser/mapProduct/' + this.circleRadius + '/' + currentLatitude + '/' + currentLongtitude, options).map(this.handleData)
                .catch(this.handleError);
        } else {
            return this.http.get(this.baseUrl + userRole.toLowerCase() + '/allProduct/' + currentUserName + '/page/' + pageNo + '/' + pageSize, options).map(this.handleData)
                .catch(this.handleError);
        }
    }
    // User searching part is pending.
    searchProperty(searchString: any): Observable<any> {

        return this.http.get(this.baseUrl + 'guestUser/mapProduct/search/' + searchString).map(this.handleData).catch(this.handleError);
    }

    searchOneProperty(access_token, productId) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('access_token', access_token);
        let options: RequestOptions = new RequestOptions({ params: params });
        return this.http.get(this.baseUrl + 'guestUser/product/search/' + productId, options).map(this.handleData)
            .catch(this.handleError);
    }

    fetchNearByProducts(latitude: any, longitude: any, radius: any): Observable<any> {
        return this.http.get(this.baseUrl + 'guestUser/mapProduct/' + radius + '/' + latitude + '/' + longitude)
            .map(this.handleData)
            .catch(this.handleError);

    }

    deleteProducts(access_token: any, properties: any): Observable<any> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('access_token', access_token);
        let options: RequestOptions = new RequestOptions({ params: params });
        return this.http.post(this.baseUrl + 'agent/products/delete/', properties, options)
            .map(this.handleResponse)
            .catch(this.handleError);
    }


    validateAccessToken(access_token: any): Observable<any> {

        let headers: Headers = new Headers();
        headers.append('access_token', access_token);

        let options: RequestOptions = new RequestOptions({ headers: headers });

        return this.http.post(this.baseUrl + 'token/validateAccessToken', {}, options)
            .map(this.handleResponse)
            .catch(this.handleErrorState);

    }//logout()

    logout(access_token: any): Observable<any> {

        let params: URLSearchParams = new URLSearchParams();
        params.set('access_token', access_token);

        let options: RequestOptions = new RequestOptions({ params: params });

        return this.http.post(this.baseUrl + 'guestUser/logout', {}, options)
            .map(res => res.text());

    }//logout()

    setProperty(value) {
        this.property = value;
        console.log(this.property);
    }

    getProperty() {
        return this.property;
    }

    setPropertyForMap(property) {
        this.propertiesForMap = property;
    }

    getPropertyForMap() {
        return this.propertiesForMap;
    }

    doUploadOnGoogleCloud(imageData: any, imageName: any) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('uploadType', 'media');
        params.set('name', imageName);

        let options = new RequestOptions({ params: params });

        return this.http.post(this.googleCloudUrl, imageData, options).map(this.handleData)
            .catch(this.handleError);
    }

    /*This is the success handler method for http requests*/
    private handleData(res: Response) {
        let body = res.json();
        return body;
    }

    private handleResponse(res: Response) {
        return res.status;
    }

    private handleErrorState(error: any) {
        return error;
    }


    /*This is the failure handler method for http requests*/
    private handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.log(error.message + ".." + error.status + ".." + error.statusText);
        return Observable.throw(errMsg);
    }

}