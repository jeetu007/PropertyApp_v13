import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';
import { DataService } from '../../service/service';
import { UserMap } from '../user-map/user-map';
import { LoadingController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { BackgroundServices } from '../../service/backgroundservices';
import { AppConfig } from '../../service/app-config';

@Component({
  selector: 'page-guest',
  templateUrl: 'guest-user.html'
})
export class GuestUserPage {


  propertyResult: any;
  showList: boolean;
  token: any;
  userRole: any;
  propertyList: any = [];
  currentUsername: any;
  public imageUrl: any;
  public imageLogo: any;
  currentLatitude: any;
  currentLongitude: any;
  isNetworkConnected: boolean;
  showSearch: boolean;
  showNavbar: boolean;

  pageNumber: number = 1;
  pageSize: number = 5;
  searchText: any;
  

  constructor(private dataService: DataService, public navCtrl: NavController, private appConfig: AppConfig,
    public navParam: NavParams, public loading: LoadingController, private toastCtrl: ToastController,
    private geolocation: Geolocation, private backGroundService: BackgroundServices) {

  }

  ionViewDidEnter() {

  }

  presentToast(mesg) {
    let toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  keyUpFun() {
    if (this.searchText.length > 0) {
      document.getElementById('clearBtn').style.display = "block";
    } else {
      document.getElementById('clearBtn').style.display = "none";
    }
  }

  clear() {
    this.searchText = "";
    document.getElementById('clearBtn').style.display = "none";
    
  }

  /*this method is used to hide the home navbar with the search navbar when search button is clicked*/
  searchButton() {
    this.showSearch = true;
    this.showNavbar = false;
  }

  //Back button 
  back(event) {
    event.preventDefault();
    this.showSearch = false;
    this.showNavbar = true;
    this.getProperties();
  }

  /*This method loads at the page loading time and gets all the registered products*/
  ionViewDidLoad() {
    this.isNetworkConnected = this.appConfig.checkNetworkConnection();
    if (!this.isNetworkConnected) {
      this.presentToast("No network detected. Please connect to a network to continue.");
      this.navCtrl.popToRoot();
    }
    else {
      let loader = this.loading.create({
        content: 'Please wait...',
      });
      loader.present().then(() => {
        this.showSearch = false;
        this.showNavbar = true;
        this.imageUrl = this.appConfig.getGoogleCouldImageUrl();
        this.imageLogo = this.appConfig.getDefaultImageLogo();
        this.currentUsername = "Guest";
        this.userRole = "";
        this.token = "";
        this.geolocation.getCurrentPosition().then((resp) => {
        this.currentLatitude = resp.coords.latitude;
        this.currentLongitude = resp.coords.longitude;
        console.log(this.currentLatitude + "||" + this.currentLongitude);

        loader.dismiss();
        this.getProperties();

        }).catch((error) => {
          loader.dismiss();
          console.log('Error getting location' + error);
        });
      });
    }
  }

  getProperties() {
    this.pageNumber = 1;
    let loader = this.loading.create({
      content: 'Loading Data..',
    });
    loader.present().then(() => {
      this.dataService.getProperties(this.token.access_token, this.userRole, this.currentUsername, this.currentLatitude, this.currentLongitude, this.pageNumber, this.pageSize)
        .subscribe(
        (response) => {
          console.log(response);
          this.propertyList = [];
          this.propertyList = response;
          console.log("response data below - ");
          console.log(this.propertyList);
          loader.dismiss();
          //this.propertyList.push(response);
        },
        (error) => {
          loader.dismiss();
          this.presentToast("Something went wrong. Try again.");
          console.log(error);
          this.navCtrl.popToRoot();
        }
        );
    });
  }

  /**
  * This method is used to search one property on the map.
  * @param value 
    @author Premnath Christopher
  */
  searchProperty(value) {
    let loader = this.loading.create({
      content: 'Searching...',
    });
    loader.present().then(() => {
      this.dataService.searchProperty(value)
        .subscribe((value) => {
          if (value == null) {
            loader.dismiss();
            this.presentToast('The Property does not exist!');
          } else {
            console.log(value);
            this.propertyResult = value;
            this.propertyList = [];
            this.propertyList = value;
            loader.dismiss();
          }
        },
        (error) => {
          this.presentToast(value + ' deoes not exist at the moment.');
          loader.dismiss();
        }
        );
    });
  }

  /*This method is used to see the property details. The navcontroller goes to the ProductDetailPage*/
  checkPropertyDetail() {
    let toast = this.toastCtrl.create({
      message: 'Only registered user can view the details. Please sign up.',
      duration: 2000,
      position: 'top'
    });
    toast.present();
  }

  /*This method is used to see all the products that are nearby to the device's location on google map*/
  showPropertyOnMap() {
    this.dataService.setPropertyForMap(this.propertyList);
    this.navCtrl.push(UserMap);
  }

  goBack() {
    this.navCtrl.pop();
  }

}
