import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ViewController } from 'ionic-angular';
import { UploadStatus } from '../upload-status/upload-status';
import { Welcome } from '../welcome/welcome';
import { DataService } from '../../service/service';
import { AppConfig } from '../../service/app-config';
import { ToastController } from 'ionic-angular';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { Events } from 'ionic-angular';





@Component({
  selector: 'pop-up',
  templateUrl: 'pop-up.html'
})
export class PopupMenu {
  public loggedInUser: any;
  public currentUsername: any;
  public userTable: any;
  public userRole: any;

  constructor(public navCtrl: NavController, public viewCtrl: ViewController, public events: Events,
    private dataService: DataService, private toastCtrl: ToastController, private sqlite: SQLite, private appConfig: AppConfig) {

  }

  ionViewDidLoad() {
    this.dataService.getCurrentUser().then((resp) => {
      console.log("PopUpPage-" + JSON.stringify(resp));
      this.loggedInUser = resp;
      this.currentUsername = this.loggedInUser.user;
      this.userRole = this.loggedInUser.authorities;
    }).catch((error) => {
      console.log(error);
    });
    this.userTable = this.appConfig.getUserTableName();
  }

  ionViewWillLeave(){
    this.viewCtrl.dismiss();
  }

  close() {
    this.viewCtrl.dismiss();
  }

  /**
* This method is used to check the upload status of the captured images.
* @param event 
* @author Vinod Kushwah
*/
  checkUploadstatus(event) {
    event.preventDefault();
    this.navCtrl.push(UploadStatus);
  }

  presentToast(mesg) {
    let toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  /**
   * This method is used to logout the user.
   * The login table from SQL lite is first cleared and then the access token is sent to be revoked to the backend.
   * @author Premnath Christopher
   */
  logout() {
    console.log(this.loggedInUser.access_token);
    this.viewCtrl.dismiss();
    let query = "DELETE FROM " + this.userTable;
    this.sqlite.create({
      name: 'data.db',
      location: 'default'
    })
      .then((db: SQLiteObject) => {

        db.executeSql(query, {})
          .then((data) => console.log('Executed SQL.Data Deleted.' + data.rows.length))
          .catch(e => console.log('Error.' + e));

      })
      .catch(e => console.log(e));
    // Remove API token 
    this.dataService.logout(this.loggedInUser.access_token)
      .subscribe(
      response => {
        let toast = this.toastCtrl.create({
          message: response,
          duration: 3000,
          position: 'top'
        });
        this.loggedInUser = [];
        toast.present();
        this.navCtrl.push(Welcome);
      },
      (error) => {
        console.log("Server Error !" + error);
        if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
          console.log("Unauthorized.");
          this.presentToast("Your session has been expired. Please login.");
          this.navCtrl.push(Welcome);
        } else {
          this.presentToast("Something went wrong. Try again.");
          console.log(error);
          this.navCtrl.push(Welcome);
        }
      }
      );
    this.events.publish('logout', 'logout');
  }

}