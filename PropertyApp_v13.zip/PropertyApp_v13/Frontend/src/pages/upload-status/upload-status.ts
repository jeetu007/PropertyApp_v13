import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { AlertController } from 'ionic-angular';
import { File, FileEntry } from '@ionic-native/file';
import { Events } from 'ionic-angular';
import { AppConfig } from '../../service/app-config';
import { DataService } from '../../service/service';



@Component({
  selector: 'upload-status',
  templateUrl: 'upload-status.html'
})
export class UploadStatus {

  uploadData: any = [];
  imageTable: any;
  isNetworkConnected : boolean;

  constructor(public navCtrl: NavController, private toastCtrl: ToastController, private sqlite: SQLite, private dataService: DataService,
    private alertCtrl: AlertController, public file: File, public events: Events, private appConfig: AppConfig) {

  }

  ionViewDidEnter() {
   
  }
  /**
   * Go back to the previous page.
   */
  goBack() {
    this.navCtrl.pop();
  }

  /**
   * On the view load , show all the selected images.
   */
  ionViewDidLoad() {
    this.isNetworkConnected = this.appConfig.checkNetworkConnection();
    if (!this.isNetworkConnected) {
      this.presentToast("No network detected. Please connect to a network to continue.");
      this.navCtrl.popToRoot();
    }
    this.imageTable = this.appConfig.getImageTableName();
    this.showRecords();
  }

  /**
   * This method is used to refresh the contents on the page.
   * 
   * @param refresher 
   * @author Premnath Christopher
   */
  doRefresh(refresher) {
    console.log('Begin async operation', refresher);

    setTimeout(() => {
      console.log('Async operation has ended');
      this.showRecords();
      refresher.complete();
    }, 2000);
  }

  /**
   * This method is used to show all the selected or captured images that are to be uploaded to the cloud.
   * @author Premnath Christopher
   */
  showRecords() {
    this.uploadData = [];
    this.sqlite.create({ name: 'data.db', location: 'default' })
      .then((db: SQLiteObject) => {
        db.executeSql('select * from ' + this.imageTable, {})
          .then((data) => {
            if (data.rows.length > 0) {
              for (let i = 0; i < data.rows.length; i++) {
                this.uploadData.push(data.rows.item(i));
                console.log(this.uploadData);
              }
            } else {
              console.log("Data could not be fetched.");
            }
          }).catch(e => console.log(e));
      }).catch(e => console.log(e));


  }

  /**
   * This method is used to present a toast notification.
   * @param mesg 
   * @author Premnath Christopher
   */
  presentToast(mesg) {
    let toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  /**
   * This method is used to try the uploading once again for the failed ones.
   */
  tryAgain() {
    console.log("try again");
    this.events.publish('upload', 'retry');
  }

  /**
   * This method is used to confirm the delete action. Presents an alert before proceeding.
   * @param item 
   * @author Premnath Christopher
   */
  confirmDelete(item) {
    let confirm = this.alertCtrl.create({
      title: 'Are you sure to delete ?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Yes',
          handler: () => {
            console.log('Agree clicked');
            this.deleteRecord(item);
          }
        }
      ]
    });
    confirm.present();
  }

  /**
   * This method is used to delete the selected image from the SQLLite.
   * @param item 
   * @author Premnath Christopher
   */
  deleteRecord(item) {
    let imagePath = item.path;
    this.removeImage(item.name);
    //---
    let query = "DELETE FROM " + this.imageTable + " WHERE name = '" + item.name + "'";
    this.sqlite.create({
      name: 'data.db',
      location: 'default'
    })
      .then((db: SQLiteObject) => {
        db.executeSql(query, {})
          .then((data) => console.log('Executed SQL.Data Deleted.' + data.rows.length))
          .catch(e => console.log('Error.' + JSON.stringify(e)));
      })
      .catch(e => console.log(JSON.stringify(e)));
    //---
    this.resolvePathFromFileSystem(imagePath);
    this.showRecords();
  }

  /**
   * This method is used to resolve a file from the file system via the incoming imagePath.
   * @param imagePath 
   * @author Premnath Christopher
   */
  resolvePathFromFileSystem(imagePath) {
    this.file.resolveLocalFilesystemUrl(imagePath)
      .then(entry => (<FileEntry>entry).file(
        file => {
          let imgLocationDetails = entry.nativeURL.split(entry.name);
          if (imgLocationDetails.length > 0) {
            this.deleteFromFileSystem(imgLocationDetails[0], entry.name);
          }
        }))
      .catch(err => console.log(err));
  }

  /**
   * This method is used to actually delete the incoming file or the selected file from the file system.
   * @param imageLocation 
   * @param imageName 
   * @author Premnath Christopher
   */
  deleteFromFileSystem(imageLocation, imageName) {
    this.file.removeFile(imageLocation, imageName).then(
      (res) => {
        console.log("Image deleted successfully.");
        this.presentToast("Image deleted successfully.");
      }
    ).catch(
      (e) => {
        console.log(JSON.stringify(e));
        this.presentToast("Something went wrong. Could't delete image.");
      }
      );
  }

  /**
   * This method is used to remove the already selected image from gallery or camera.
   * @param name 
   * @author Premnath Christopher
   */
  removeImage(name) {
    const index: number = this.uploadData.indexOf(name);
    if (index !== -1) {
      this.uploadData.splice(index, 1);
    }
  }


}
