import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { DataService } from '../../service/service';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { File, FileEntry } from '@ionic-native/file';
import { Geolocation } from '@ionic-native/geolocation';
import { LoadingController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { UUID } from 'angular2-uuid';
import { BackgroundMode } from '@ionic-native/background-mode';
import { AppConfig } from '../../service/app-config';


@Component({
  selector: 'user-registration',
  templateUrl: 'user-registration.html'
})
export class UserRegistrationPage {

  token: any;
  propertyResult: any;
  formData: FormData;
  currentLatitude: any;
  currentLongitude: any;
  userForm: FormGroup;
  userData: any;
  cameraClick: boolean = false;
  userImage: any;
  userImageName: any;
  isNetworkConnected: boolean;

  constructor(public navCtrl: NavController, private dataService: DataService, public file: File,
    public camera: Camera, private formBuilder: FormBuilder, private geolocation: Geolocation, public appConfig: AppConfig,
    public loading: LoadingController, private toastCtrl: ToastController, public backgroundMode: BackgroundMode) {

    this.userForm = this.formBuilder.group({
      firstName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      lastName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      address: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      mobile: ['', Validators.compose([Validators.minLength(5), Validators.maxLength(30), Validators.pattern('[0-9]*'), Validators.required])],
      email: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(10), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      password: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.required])],
      remark: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      role: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      username: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])]

    });
  }


  goBack() {
    this.navCtrl.pop();
  }

  ionViewDidLoad() {
    this.isNetworkConnected = this.appConfig.checkNetworkConnection();
    if (!this.isNetworkConnected) {
      this.presentToast("No network detected. Please connect to a network to continue.");
      this.navCtrl.popToRoot();
    }
    this.geolocation.getCurrentPosition().then((resp) => {
      this.currentLatitude = resp.coords.latitude;
      this.currentLongitude = resp.coords.longitude;
    }).catch((error) => {
      console.log('Error getting location' + error);
    });
    this.formData = new FormData();
  }

  /*this method is used to take the picture using the device's camera.*/
  takePicture(event) {
    event.preventDefault();
    let toast = this.toastCtrl.create({
      message: 'Sorry ! please try again.!',
      duration: 2000,
      position: 'top'
    });
    this.cameraClick = true;
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      saveToPhotoAlbum: true
    }

    this.camera.getPicture(options).then((imageData) => {
      this.userImage = imageData;
      this.file.resolveLocalFilesystemUrl(imageData)
        .then(entry => (<FileEntry>entry).file(file => this.readImageFile(file)))
        .catch(err => console.log(err));
    }, (err) => {
      toast.present();
    });
  }

  /*This method is used to read the captured image and then upload it to the google cloud storage with a unique name.
  This method also saves one copy of the image in the application's specified folder.'*/
  readImageFile(file: any) {
    let toast = this.toastCtrl.create({
      message: 'Image Saved Successfully!',
      duration: 2000,
      position: 'top'
    });
    let errorToast = this.toastCtrl.create({
      message: 'Sorry.Image file could not be stored!',
      duration: 2000,
      position: 'top'
    });
    const reader = new FileReader();
    reader.onloadend = () => {
      const imageBlob = new Blob([reader.result], { type: file.type });
      //this.formData.append('userImage', imageBlob, file.name);
      let uuid = UUID.UUID();
      this.userImageName = "user-" + uuid + ".jpg";
      let loader = this.loading.create({
        content: 'Saving Image.Please wait...',
      });
      loader.present().then(() => {
        this.file.writeFile(this.file.externalDataDirectory + 'user',
          this.userImageName, imageBlob, true)
          .then(res => {
            this.uploadCloudData(imageBlob, this.userImageName);
            loader.dismiss();
            toast.present();
          })
          .catch(err => {
            loader.dismiss();
            errorToast.present();
          });
      });

    };
    reader.readAsArrayBuffer(file);
  }


  /*This method is used to upload all the user data along with the captured image file.
  The data is bound to the Formdata and then sent to the server.*/
  uploadData(event) {
    event.preventDefault();
    this.userData = [
      {
        "address": this.userForm.value.address,
        "email": this.userForm.value.email,
        "firstName": this.userForm.value.firstName,
        "lastName": this.userForm.value.lastName,
        "mobile": this.userForm.value.mobile,
        "password": this.userForm.value.password,
        "remark": this.userForm.value.remark,
        "role": this.userForm.value.role,
        "username": this.userForm.value.username,
        "currentLatitude": this.currentLatitude,
        "currentLongitude": this.currentLongitude,
        "image": this.userImageName
      }
    ]
    console.log(this.userData);
    // this.formData.append('userData',
    //             new Blob([JSON.stringify(this.userData)],{type: "application/json"}));
    let toast = this.toastCtrl.create({
      message: 'Registration Successful! You can login after user validation. !',
      duration: 5000,
      position: 'top'
    });
    let errorToast = this.toastCtrl.create({
      message: 'Sorry ! please try again.!',
      duration: 2000,
      position: 'top'
    });
    let loader = this.loading.create({
      content: 'Please wait...',
    });
    loader.present().then(() => {
      this.dataService.doUserRegistration(this.userData)
        .subscribe(
        response => {
          if (response == 200 || response === 200) {
            loader.dismiss();
            toast.present();
            this.userForm.reset();
            this.userData = [];
            this.formData = new FormData();
            this.userImageName = "";
            this.navCtrl.popToRoot();
          } else {
            loader.dismiss();
            errorToast.present();
          }
        },
        error => {
          loader.dismiss();
          errorToast.present();
        }
        );
    });
  }

  uploadCloudData(imageBlob: any, userImageName: any) {
    this.backgroundMode.enable();
    this.backgroundMode.on("activate").subscribe((res) => {
      this.dataService.doUploadOnGoogleCloud(imageBlob, userImageName).subscribe(
        response => {
          console.log(response);
        },
        error => {
          console.log("error - " + error);
        }
      );
    }, (error) => {
      console.log("BackGround error - " + error);
    });
  }

  presentToast(mesg) {
    let toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }


}
