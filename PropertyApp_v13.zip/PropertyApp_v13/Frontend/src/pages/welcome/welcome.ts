import { Component } from '@angular/core';
import { NavController, Platform } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { DataService } from '../../service/service';
import { UserPage } from '../user-page/user-page';
import { ProductPage } from '../product/product';
import { UserRegistrationPage } from '../user-registration/user-registration';
import { GuestUserPage } from '../guest-user/guest-user';
import { LoadingController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { BackgroundServices } from '../../service/backgroundservices';
import { BackgroundMode } from '@ionic-native/background-mode';
import { AppConfig } from '../../service/app-config';
import { Events } from 'ionic-angular';



@Component({
  selector: 'page-welcome',
  templateUrl: 'welcome.html',
})
export class Welcome {

  public loggedInUser: any;
  public currentUser: any;
  public userName: any;
  public userTable: String;
  public isNetworkConnected: boolean;


  constructor(platform: Platform, public navCtrl: NavController, public alertCtrl: AlertController, public appConfig: AppConfig,
    private dataService: DataService, public loading: LoadingController, private toastCtrl: ToastController, public events: Events,
    private sqlite: SQLite, public backgroundServices: BackgroundServices, public backgroundMode: BackgroundMode) {

    platform.ready().then((res) => {
      platform.registerBackButtonAction(() => this.exitApp());
      this.backgroundMode.on('deactivate').subscribe((data) => {
        this.alertStatus = true;
      }, (error) => { console.log("Something is wrong !! " + JSON.stringify(error)); });
    }, (error) => { console.log("Something is wrong !! " + JSON.stringify(error)); });

    this.events.subscribe('logout', (action) => {
      this.navCtrl.popToRoot();
    });
  }

  presentToast(mesg) {
    let toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  status: number = 0;
  alertStatus: any = true;
  alertBox: any;

  exitApp() {
    if (this.alertStatus) {
      this.alertBox = this.alertCtrl.create({
        title: 'Confirmation',
        message: 'Do you want to exit?',
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              console.log('Cancel clicked');
              this.alertStatus = true;
            }
          },
          {
            text: 'OK',
            handler: () => {
              this.alertStatus = true;
              this.backgroundMode.moveToBackground();
            }
          }
        ]
      });
    }

    this.status++;
    setTimeout(() => {
      this.status = 0;
    }, 1500);

    if (this.status == 2) {
      this.alertBox.dismiss();
      this.backgroundMode.moveToBackground();
    } else {

      if (this.navCtrl.canGoBack()) {

        if (this.navCtrl.first()['index'] + 1 == this.navCtrl.getActive()['index']) {
          if (this.alertStatus) {
            this.alertBox.present();
            this.alertStatus = false;
          }
        } else { this.navCtrl.pop(); }

      } else {
        if (this.alertStatus) {
          this.alertBox.present();
          this.alertStatus = false;
        }
      }
    }
  }

  ionViewDidEnter() {
    this.navCtrl.popToRoot();
  }
  /**
   * This method is checking whether the access token has been expired or not. If it is alive then redirect to the 
   * logged in user role page else ask for login.
   * @author - Premnath Christopher
   */
  ionViewDidLoad() {
    this.isNetworkConnected = this.appConfig.checkNetworkConnection();
    this.userTable = this.appConfig.getUserTableName();
    if (this.isNetworkConnected) {
      this.dataService.getCurrentUser()
        .then((resp) => {
          console.log("SQL Lite_WelcomePage ==> " + JSON.stringify(resp));
          this.loggedInUser = resp;
          this.authenticateUser(this.loggedInUser.access_token, this.loggedInUser.refresh_token);
        })
        .catch((error) => {
          console.log(error);
          //this.presentToast("Plugin not found.Please login to continue..");
        });
    } else {
      this.presentToast("No network detected. Please connect to a network to continue.");
    }

  }

  /**
   * This method is used to validate one access token from backend.
   * @param access_token 
   * @author - Premnath Christopher
   */
  authenticateUser(access_token, refresh_token) {
    this.dataService.validateAccessToken(access_token).subscribe(
      (res) => {
        console.log("Validation res- " + res);
        if (res == 200) {
          this.authorizeUser();
        } else if (res == 226) {
          console.log("tokenStatus--" + res);
          console.log("Access token is expired.");
          //--Check refresh token availability. 226
          this.validateRefreshToken(refresh_token);
          //--400 and 401
          //this.presentToast("Your session has been expired. Please login again.");
          //this.navCtrl.popToRoot();
        } else {
          console.log("tokenStatus--" + res);
          console.log("Refresh token is expired.");
          this.presentToast("Your session has been expired. Please login again.");
          this.navCtrl.popToRoot();
        }
      },
      (err) => {
        console.log("Validate err -" + err);
        this.presentToast("Invalid Session.");
      }
    );
  }

  /**
  * This method is used whenever the access token gets expired. 
  * This method refreshes the logged in user tokens using the refresh token.
  * This method also validates whether the refresh token is alive or expired.
  * @param refresh_token 
  * @author Premnath Christopher
  */
  validateRefreshToken(refresh_token) {
    this.dataService.validateRefreshToken(refresh_token).subscribe(
      (res) => {
        this.dataService.setCurrentUser(res, this.userName);
        console.log("Using Refresh Token - " + JSON.stringify(res));
        this.loggedInUser = res;
        this.authorizeUser();
      }, (err) => {
        console.log(err);
        this.presentToast("Your session has been expired. Please login again.");
      }
    );
  }

  /**
   * This method is used to provide the authority to the user as per role.
   * @author Premnath Christopher
   */
  authorizeUser() {
    if (this.loggedInUser.authorities == "AGENT") {
      this.navCtrl.push(ProductPage);
    } else if (this.loggedInUser.authorities == "USER") {
      this.navCtrl.push(UserPage);
    } else {
      console.log("Neither Agent nor User. Some other role.");
      this.presentToast("Please login on the Web.");
      this.navCtrl.popToRoot();
    }
  }


  /**
   * This is the alert login box.
   */
  login() {
    let prompt = this.alertCtrl.create({
      title: 'Login',
      inputs: [
        {
          name: 'Username',
          placeholder: 'Enter Username'
        },
        {
          name: 'Password',
          placeholder: 'Enter Password',
          type: 'password'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Login',
          handler: data => {
            if (this.isNetworkConnected) {
              this.doUserLogin(data.Username, data.Password);
            } else {
              this.presentToast("No network detected");
            }
          }
        }
      ]
    });
    prompt.present();
  }

  /**
   * This method is used to do the login with the specified username and passsword.
   * This method also redirects the logged in user to its respective homepage as
   * per the user role.
   * The login details are then stored in SQL Lite.
   * @param username 
   * @param password 
   * @author - Premnath Christopher
   */
  doUserLogin(username, password) {
    this.userName = username;
    console.log("Login Username - " + this.userName);
    console.log("User Table  - " + this.userTable);

    let loader = this.loading.create({
      content: 'Logging in...',
    });
    loader.present().then(() => {
      this.dataService.doLogin(username, password)
        .subscribe(
        response => {
          this.sqlite.create({
            name: 'data.db',
            location: 'default'
          })
            .then((db: SQLiteObject) => {
              let query = 'INSERT INTO ' + this.userTable + '(access_token,authorities,expires_in,refresh_token,scope,token_type,user,username) VALUES(?,?,?,?,?,?,?,?)';
              db.executeSql(query,
                [response.access_token, response.authorities, response.expires_in, response.refresh_token, response.scope, response.token_type, response.user, username])
                .then(() => console.log('Data Inserted.'))
                .catch(e => console.log('Insert Error- ' + JSON.stringify(e)));
            })
            .catch(e => console.log("sql lite error." + JSON.stringify(e)));
          console.log(response);
          //check role and redirect to homepage.
          if (response.authorities == "AGENT") {
            this.navCtrl.push(ProductPage);
          } else if (response.authorities == "USER") {
            this.navCtrl.push(UserPage);
          } else {
            this.presentToast('Please login on the WEB.');
          }
          loader.dismiss();
        },
        error => {
          loader.dismiss();
          this.presentToast('Please use valid credentials !');
        }
        );
    });


  }

  /*This method redirects to the user registration page.
  */
  signup() {
    this.navCtrl.push(UserRegistrationPage);
  }

  /*This method redirects to guest user page. login not needed.
  */
  skip() {
    this.navCtrl.push(GuestUserPage);
  }
}