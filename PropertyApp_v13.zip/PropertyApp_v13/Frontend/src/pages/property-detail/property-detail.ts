import { Component, ViewChild  } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { DataService } from '../../service/service';
import { ImagePicker } from '@ionic-native/image-picker';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { ToastController } from 'ionic-angular';
import { File, FileEntry } from '@ionic-native/file';
import { UUID } from 'angular2-uuid';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { ImageResizer, ImageResizerOptions } from '@ionic-native/image-resizer';
import { LoadingController } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { AlertController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { Events } from 'ionic-angular';
import { AppConfig } from '../../service/app-config';


import { Content } from 'ionic-angular';


@Component({
  selector: 'property-detail',
  templateUrl: 'property-detail.html'
})
export class PropertyDetailPage {

  @ViewChild(Content) content: Content;

  forDisplayDetails: boolean = true;
  forUpdateDetails: boolean = false;
  property: any;
  public imageUrl: any;
  public imageLogo: any;
  propertyDetail: any = [];
  propertyImage: any;
  propertyImagesList: any = [];
  imageBlobList: any = [];
  thumbnilBlobList: any = [];
  propertyThumbnilName: any;
  PropertyCloudThumbnilUrlList: any = [];
  thumbnilPropertyImageDisplay: any = [];
  propertyImageName: any;
  PropertyCloudImageUrlList: any = [];
  cameraClick: boolean = false;
  loggedInUser: any;
  currentUsername: any;
  userRole: any;
  userForm: FormGroup;
  errMesg: string = "something went wrong! please, try again.";
  propertyData: any;
  currentLatitude: any;
  currentLongitude: any;
  public imageTable: any;


  constructor(
    private geolocation: Geolocation, public navCtrl: NavController, public navParams: NavParams,
    private dataService: DataService, private imagePicker: ImagePicker,
    private camera: Camera, private toastCtrl: ToastController, public file: File, private imageResizer: ImageResizer,
    private sqlite: SQLite, private formBuilder: FormBuilder, public loading: LoadingController,
    private alertCtrl: AlertController, public events: Events, private appConfig: AppConfig) {

    this.userForm = this.formBuilder.group({
      brandName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      modelName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      locationTag: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      price: ['', Validators.compose([Validators.minLength(5), Validators.maxLength(10), Validators.pattern('[0-9]*'), Validators.required])],
      width: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(10), Validators.pattern('[0-9]*'), Validators.required])],
      height: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.required])],
      remark: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      attributeName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      attributeDisplayName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      attributeValue: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])]
    });
  }

  ionViewDidEnter() {


    //for getting imarg google cloud url
    this.imageUrl = this.appConfig.getGoogleCouldImageUrl();
    this.imageLogo = this.appConfig.getDefaultImageLogo();
    this.dataService.getCurrentUser().then((resp) => {
      console.log("ProductDetailPage-" + JSON.stringify(resp));
      this.loggedInUser = resp;
      this.currentUsername = this.loggedInUser.user;
      this.userRole = this.loggedInUser.authorities;
    }).catch((error) => {
      console.log(error);
    });
  }

  ionViewDidLoad() {
    this.imageTable = this.appConfig.getImageTableName();
    if (this.dataService.getProperty() != null) {
      let loader = this.loading.create({
        content: 'Fetching details...',
      });
      loader.present().then(() => {
        this.propertyDetail = this.dataService.getProperty();
        loader.dismiss();
      })
    }

    if (this.navParams.get("propertyDetail") != null) {
      let loader = this.loading.create({
        content: 'Fetching details...',
      });
      loader.present().then(() => {
        this.propertyDetail = [];
        this.propertyDetail.push(this.navParams.get("propertyDetail"));
        console.log("Property detail - " + JSON.stringify(this.propertyDetail));
        loader.dismiss();
      })
    }
  }


  /**
   * Author: Darshan Makwana
   * @param event 
   * This is for setting current location, while updating property record
   */
  setGeoLocation(event) {
    event.preventDefault();
    let loader = this.loading.create({
      content: 'Please wait..',
    });
    loader.present().then(() => {
      this.geolocation.getCurrentPosition().then((resp) => {
        this.propertyDetail[0].latitude = resp.coords.latitude;
        this.propertyDetail[0].longitude = resp.coords.longitude;
        loader.dismiss();
        this.presentToast("Current location set successfully.");
      }).catch((error) => {
        console.log('Error getting location' + error);
        loader.dismiss();
        this.presentToast("Try again, something went wrong while setting current location.");
      });
    })
  }

  /**
   * To check Display Details or Update Details
   * by Default : forDisplayDetails: boolean = true;
   *              forUpdateDetails : boolean = false;
   */
  displayDetails() {
    this.forUpdateDetails = false;
    this.forDisplayDetails = true;
  }

  updateDetails() {
    this.content.scrollToTop();
    this.forDisplayDetails = false;
    this.forUpdateDetails = true;
  }


  /**
   * 
   * @param imgUrl : this is image name for identifiy which image need to be remove.
   * @param type   : for chacking condition which image is need to be delete from new captureing image or previous image
   *                 this is for image type. it would be "previous" or "new image". 
   * first it will ask for confirmation for delete image. 
   * if delete image type is previous. it will go http call and go into db and delete iamge as well as delete from redis also.
   * in response we conform image delete successfully. we need to delete from local propertyDetail variable also.
   * if image url type is new so, will remove new capture image or selected image from propertyImagesList array varibale.
   */
  removeImage(imgUrl, type) {

    let alert = this.alertCtrl.create({
      title: 'Are you sure to delete image?',
      message: 'Click OK  to delete the image.',
      buttons: [
        {
          text: 'OK',
          handler: () => {
            if (type == 'previous') {
              let loader = this.loading.create({
                content: 'Please wait..',
              });
              loader.present().then(() => {
                this.dataService.doDeleteProductImage(imgUrl, this.loggedInUser.access_token)
                  .subscribe(res => {
                    if (res === 200) {
                      console.log("ok, image deleted");
                    }

                    let imglist = this.propertyDetail[0].imageList;
                    for (let i = 0; i < imglist.length; i++) {
                      if (imglist[i].image === imgUrl) {
                        imglist.splice(i, 1);
                      }
                    }

                    console.log(res);
                    loader.dismiss();
                  }, err => {
                    console.log(err);
                    this.presentToast(this.errMesg);
                    loader.dismiss();
                  })

              });
            } else {

              let loader = this.loading.create({
                content: 'Please wait..',
              });
              loader.present().then(() => {
                for (let i = 0; i < this.propertyImagesList.length; i++) {
                  if (this.propertyImagesList[i] === imgUrl) {
                    console.log("remove......");
                    this.propertyImagesList.splice(i, 1);

                  }
                }
              });
            }
          }
        },
        {
          text: 'CANCEL',
          handler: () => {
            console.log('Agree clicked');
          }
        }
      ]
    });

    alert.present();
  }//end removeImage();

  presentToast(mesg) {
    let toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  /**This method uses the ImagePicker cordova plugin to select multiple images at once. */
  addImages(event) {
    event.preventDefault();
    this.cameraClick = true;
    let options = {
      // max images to be selected, defaults to 15. If this is set to 1, upon
      // selection of a single image, the plugin will return it.
      maximumImagesCount: 15,

      // max width and height to allow the images to be.  Will keep aspect
      // ratio no matter what.  So if both are 800, the returned image
      // will be at most 800 pixels wide and 800 pixels tall.  If the width is
      // 800 and height 0 the image will be 800 pixels wide if the source
      // is at least that wide.
      width: 3006,
      height: 5344,

      // quality of resized image, defaults to 100
      quality: 100
    };
    this.imagePicker.getPictures(options).then((results) => {
      for (let i = 0; i < results.length; i++) {
        console.log('Image URI: ' + results[i]);
        this.propertyImage = results[i];
        this.propertyImagesList.push(this.propertyImage);
        this.file.resolveLocalFilesystemUrl(results[i])
          .then(entry => (<FileEntry>entry).file(file => { this.readImageFile(file, results[i], "original"); this.imageResizerthumbnail(results[i]); }))
          .catch(err => console.log(err));
      }
    }, (err) => {
      this.presentToast("Something went wrong in ImagePicker !!");
    });
  }

  //To take picture...
  takePicture(event) {
    event.preventDefault();
    let toast = this.toastCtrl.create({
      message: 'Sorry ! please try again.!',
      duration: 2000,
      position: 'top'
    });
    this.cameraClick = true;
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      saveToPhotoAlbum: true
    }
    this.camera.getPicture(options).then((imageData) => {
      this.propertyImage = imageData;
      this.propertyImagesList.push(this.propertyImage);
      this.file.resolveLocalFilesystemUrl(imageData)
        .then(entry => (<FileEntry>entry).file(file => { this.readImageFile(file, imageData, "original"); this.imageResizerthumbnail(imageData); }))
        .catch(err => console.log(err));
    }, (err) => {
      toast.present();
    });
  }//end take picture..



  /** This method is used to read the file from the android file system, generate a  respective blob, provide an unique name and store 
   * the same in a list as well as in SQLLite.
  */
  readImageFile(file: any, filepath, propertyName: any) {
    const reader = new FileReader();
    reader.onloadend = () => {
      let imageBlob = new Blob([reader.result], { type: file.type });

      if (propertyName != "thumbnail") {
        let uuid = UUID.UUID();
        this.propertyImageName = "property-" + uuid + ".jpg";
        //list of images as blob
        this.imageBlobList.push(imageBlob);
        //list of cloud image url.
        this.PropertyCloudImageUrlList.push(this.propertyImageName);
        //this is for storing data into sqlite
        this.imagePathForSQLite(this.propertyImageName, filepath);
      } else {
        //list of thubnail image 
        this.thumbnilBlobList.push(imageBlob);
        let uuid = UUID.UUID();
        this.propertyThumbnilName = "propertythumbnail-" + uuid + ".jpg";
        //this is for containing thumbnail url image list.
        this.PropertyCloudThumbnilUrlList.push(this.propertyThumbnilName);
        //this is for storing data into sqlite
        this.imagePathForSQLite(this.propertyThumbnilName, filepath);
      }
    };
    reader.readAsArrayBuffer(file);
  }//end readImageFile()


  /**This method is used to resize the so captured images and prepare thumbnails of it. */
  imageResizerthumbnail(uri) {
    let options = {
      uri: uri,
      folderName: 'Protonet',
      quality: 90,
      width: 500,
      height: 500
    } as ImageResizerOptions;

    this.imageResizer
      .resize(options)
      .then((filePath: string) => {

        this.thumbnilPropertyImageDisplay.push(filePath);
        this.file.resolveLocalFilesystemUrl(filePath)
          .then(entry => (<FileEntry>entry).file(file => {
            this.readImageFile(file, filePath, "thumbnail");
          }
          ))
          .catch(err => console.log(err));
      })
      .catch(e => console.log(e));
  }//end iamgeResizerThumbnail()

  /**
* This is for reading file.
* @param file To read file and store into list.
*/



  //for uploading image path and thumbnail path on sqlite.
  imagePathForSQLite(uuidname, filepath) {

    this.sqlite.create({
      name: 'data.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
      db.executeSql('INSERT INTO ' + this.imageTable + ' (name,path,status) VALUES(?,?,?)', [uuidname, filepath, "pending"])
        .then(() => console.log('image data is inserted ..............'))
        .catch(e => { console.log('image data is not inserted ..............'); console.log(e) });
    }).catch(e => console.log('image data is not inserted ..............'));

  }

  goBack() {
    this.navCtrl.pop();
  }

  uploadData() {
    this.events.publish('upload', 'upload');
    console.log(JSON.stringify(this.propertyDetail));
    this.propertyData = [
      {
        "productId": this.propertyDetail[0].productId,
        "brandName": this.userForm.value.brandName,
        "modelName": this.userForm.value.modelName,
        "locationTag": this.userForm.value.locationTag,
        "price": this.userForm.value.price,
        "width": this.userForm.value.width,
        "height": this.userForm.value.height,
        "latitude": this.propertyDetail[0].latitude,
        "longitude": this.propertyDetail[0].longitude,
        "remark": this.userForm.value.remark,
        "createdOn": this.propertyDetail[0].createdOn,
        "lastModifiedUser": {
          "userId": 1
        },
        "extraAttributeList": [
          {
            "extraAttributeId": this.propertyDetail[0].extraAttributeList[0].extraAttributeId,
            "attributeName": this.userForm.value.attributeName,
            "attributeDisplayName": this.userForm.value.attributeDisplayName,
            "attributeValue": this.userForm.value.attributeValue,
            "createdOn": this.propertyDetail[0].extraAttributeList[0].createdOn,
          }
        ],
        "imageUrlList": this.PropertyCloudImageUrlList,
        "shortImageUrlList": this.PropertyCloudThumbnilUrlList,

        "previousimage": this.propertyDetail[0].imageList
      }
    ]

    /********************* For register peorudct ***********************/
    //for testing service registration...
    let loader = this.loading.create({
      content: 'Please wait..',
    });
    loader.present().then(() => {
      this.dataService.doUpdatePropertyData(this.propertyData,
        this.loggedInUser.access_token)
        .subscribe(
        (res) => {
          loader.dismiss();
          this.presentToast("Property data update successfully !!");
        }, (error) => {
          if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
            console.log("Access Token Expired.");
            this.validateRefreshToken(this.loggedInUser.refresh_token);
            this.uploadData();
          }
          loader.dismiss();
          this.presentToast("Something went wrong");
        }
        );
    });

    /*******************************************************************/
  }//end uploadData

  /**
   * This method is used whenever the access token gets expired. 
   * This method refreshes the logged in user tokens using the refresh token.
   * This method also validates whether the refresh token is alive or expired.
   * @param refresh_token 
   * @author Premnath Christopher
   */
  validateRefreshToken(refresh_token) {
    this.dataService.validateRefreshToken(refresh_token).subscribe(
      (res) => {
        this.dataService.setCurrentUser(res, this.loggedInUser.username);
        console.log("Using Refresh Token - " + JSON.stringify(res));
        this.loggedInUser = res;
        this.currentUsername = this.loggedInUser.user;
      }, (err) => {
        console.log(err);
        this.presentToast("Your session has been expired. Please login again.");
        this.navCtrl.popToRoot();
      }
    );
  }





}
