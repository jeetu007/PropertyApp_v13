import { Component, NgZone, ViewChild, ElementRef } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { DataService } from '../../service/service';
import { PropertyDetailPage } from '../property-detail/property-detail';
import { ToastController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';
import { AppConfig } from '../../service/app-config';




declare var google;

@Component({
    selector: 'user-map',
    templateUrl: 'user-map.html'
})
export class UserMap {

    @ViewChild('usermap') mapElement: ElementRef;
    usermap: any;
    currentLatitude: any;
    currentLongitude: any;
    propertyDetails: any;
    private circleRadius: any;
    //private everyTimeRefresh: any = true;
    token: any;
    userRole: any
    numberOfProperties: any;
    public loggedInUser: any;
    currentUsername: any;
    public imageUrl: any;
    public imageLogo: any;
    public isNetworkConnected: boolean;



    constructor(public navCtrl: NavController, private geolocation: Geolocation, private appConfig: AppConfig,
        private dataService: DataService, public ngZone: NgZone, public navParams: NavParams,
        private toastCtrl: ToastController, public loading: LoadingController) {
    }

    presentToast(mesg) {
        let toast = this.toastCtrl.create({
            message: mesg,
            duration: 3000,
            position: 'top'
        });

        toast.present();
    }

    ionViewDidEnter() {
        this.isNetworkConnected = this.appConfig.checkNetworkConnection();
        if (this.isNetworkConnected) {
            //----------
            this.dataService.getCurrentUser().then((resp) => {
                console.log("UserMapPage-" + JSON.stringify(resp));
                this.loggedInUser = resp;
                if (this.loggedInUser == undefined || this.loggedInUser == "" || this.loggedInUser == null) {
                    this.currentUsername = "Guest";
                } else {
                    this.currentUsername = this.loggedInUser.user;
                }
            }).catch((error) => {
                console.log(error);
            });
            //----------
            if (this.navParams.get("searchedLatLong") == undefined) {
                this.locateMe();
            } else {
                let searchedProperty = this.navParams.get("searchedLatLong");
                console.log(searchedProperty[0].latitude + ", " + searchedProperty[0].longitude);
                this.loadUserMap(searchedProperty);
            }
        } else {
            this.presentToast("No network detected. Please connect to a network to continue.");
            this.navCtrl.popToRoot();
        }

    }
    /*This method checks whether a search request is available or not for a property.
    If the search request is present , then the map shows the searched property on the map.
    If there is no search request , then the google map loads with the device's current location as
    center and shows al the nearby registered properties.'*/
    ionViewDidLoad() {
        this.imageUrl = this.appConfig.getGoogleCouldImageUrl();
        this.imageLogo = this.appConfig.getDefaultImageLogo();

        this.circleRadius = 5000;
        window["angularComponentRef"] = { component: this, zone: this.ngZone };
    }

    searchProperty(value) {
        let loader = this.loading.create({
            content: 'Searching...',
        });
        loader.present().then(() => {
            this.dataService.searchProperty(value)
                .subscribe(value => {
                    if (value == null) {
                        loader.dismiss();
                        this.presentToast('The Property does not exist!');
                    } else {
                        console.log(value);
                        loader.dismiss();
                        this.dataService.setPropertyForMap(value);
                        let myOptions = {
                            zoom: 12,
                            center: new google.maps.LatLng(value[0].latitude, value[0].longitude),
                            mapTypeId: google.maps.MapTypeId.ROADMAP,
                            animation: google.maps.Animation.BOUNCE
                        };
                        this.usermap = new google.maps.Map(document.getElementById("usermap"), myOptions);
                        //----
                        let infowindow = new google.maps.InfoWindow({
                            content: " "
                        });

                        let marker = new google.maps.Marker({
                            position: new google.maps.LatLng(value[0].latitude, value[0].longitude),
                            animation: google.maps.Animation.DROP,
                        });

                        marker.addListener('click', function () {
                            infowindow.setContent('<img src="assets/img/logo.jpg" style="height:50px;width:50px;"><br>'
                                + '<p>Name: ' + value[0].brandName + '</p>' +
                                '<p>Latitude: ' + value[0].modelName + '</p>' +
                                '<p>Longitude: ' + value[0].price + '</p>' +
                                `<button type="button" onclick="window.angularComponentRef.zone.run(() => {window.angularComponentRef.component.goToPropertyDetail(` + value[0].productId + `);})">` + `Show More</button>`);
                            infowindow.open(this.map, marker);
                            this.map.setCenter(marker.position);
                        });

                        // google.maps.event.trigger(marker, 'click');
                        marker.setMap(this.usermap);
                        //----
                        let cityCircle = new google.maps.Circle({
                            strokeColor: '#D68910',
                            strokeOpacity: 0.8,
                            strokeWeight: 2,
                            fillColor: '#5DADE2',
                            fillOpacity: 0.35,
                            map: this.usermap,
                            center: new google.maps.LatLng(value[0].latitude, value[0].longitude),
                            radius: this.circleRadius,
                            draggable: true,
                            editable: true
                        });

                        this.getTheNearByProperties();

                        cityCircle.addListener('radius_changed', (event) => {
                            this.refreshNearByProducts(cityCircle.getCenter().lat(), cityCircle.getCenter().lng(), cityCircle.getRadius());
                        });

                        cityCircle.setMap(this.usermap);

                        google.maps.event.addListener(this.usermap, 'click', (event) => {
                            cityCircle.setCenter(new google.maps.LatLng(event.latLng.lat(), event.latLng.lng()));
                            this.refreshNearByProducts(event.latLng.lat(), event.latLng.lng(), cityCircle.getRadius());
                        });

                        marker.addListener('drag', (event) => {
                            cityCircle.setOptions({ center: { lat: event.latLng.lat(), lng: event.latLng.lng() } });
                            this.refreshNearByProducts(event.latLng.lat(), event.latLng.lng(), cityCircle.getRadius());
                        });
                        if (this.dataService.getPropertyForMap() != null) {
                            this.getTheNearByProperties();
                        }
                    }
                },
                err => {
                    let errorToast = this.toastCtrl.create({
                        message: value + ' does not exist at the moment.',
                        duration: 3000,
                        position: 'top'
                    });
                    errorToast.present();
                }
                );
        }, (err) => {
            console.log(err);
            loader.dismiss();
        });


    }
    /*This method is used to*/
    loadUserMap(property) {

        let loader = this.loading.create({
            content: 'Loading map...',
            dismissOnPageChange: true
        });
        loader.present().then(() => {
            let myOptions = {
                zoom: 12,
                center: new google.maps.LatLng(property[0].latitude, property[0].longitude),
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                animation: google.maps.Animation.BOUNCE
            };

            this.usermap = new google.maps.Map(document.getElementById("usermap"), myOptions);

            this.dataService.setPropertyForMap(property);
            this.getTheNearByProperties();
            loader.dismiss();


            //----
            let infowindow = new google.maps.InfoWindow({
                content: " "
            });

            let marker = new google.maps.Marker({
                position: new google.maps.LatLng(property[0].latitude, property[0].longitude),
                animation: google.maps.Animation.DROP,
            });

            marker.addListener('click', function () {
                infowindow.setContent('<img src="assets/img/logo.jpg" style="height:50px;width:50px;"><br>'
                    + '<p>Name: ' + property[0].brandName + '</p>' +
                    '<p>Latitude: ' + property[0].modelName + '</p>' +
                    '<p>Longitude: ' + property[0].price + '</p>' +
                    `<button type="button" onclick="window.angularComponentRef.zone.run(() => {window.angularComponentRef.component.goToPropertyDetail(` + property[0].productId + `);})">` + `Show More</button>`);
                infowindow.open(this.map, marker);
                this.map.setCenter(marker.position);
            });

            // google.maps.event.trigger(marker, 'click');
            marker.setMap(this.usermap);
            //----

            google.maps.event.addListener(this.usermap, 'click', (event) => {
                console.log("clicked !!");
                /* cityCircle.setCenter(new google.maps.LatLng(event.latLng.lat(),event.latLng.lng()));
                 this.refreshNearByUsers(event.latLng.lat(),event.latLng.lng(),cityCircle.getRadius());*/
            });

            marker.addListener('drag', (event) => {
                console.log("Dragged !!");
                /* cityCircle.setOptions({center:{lat:event.latLng.lat(),lng:event.latLng.lng()}});
                 this.refreshNearByUsers(event.latLng.lat(),event.latLng.lng(),cityCircle.getRadius());*/
            });
            //this.dataService.removeSearchedUser();
        }, (err) => {
            console.log(err);
            loader.dismiss();
        });


    }

    refreshNearByProducts(latitude: any, longitude: any, newRadius: any): void {
        let changedRadius = Math.round(newRadius);
        this.dataService.fetchNearByProducts(latitude, longitude, changedRadius)
            .subscribe(
            response => {
                console.log("Inside the refreshNearByUsers :: Response");
                this.dataService.setPropertyForMap(response);
                this.getTheNearByProperties();
            },
            error => {
                console.log("Server Error !" + error);
                this.presentToast("Something went wrong !!");
            }
            );
    }

    getTheNearByProperties() {

        this.propertyDetails = this.dataService.getPropertyForMap();
        this.numberOfProperties = this.propertyDetails.length;
        console.log(this.numberOfProperties);
        console.log("loop of users next...");
        for (let property of this.propertyDetails) {
            let infowindow = new google.maps.InfoWindow({
                content: " "
            });

            let marker = new google.maps.Marker({
                position: new google.maps.LatLng(property.latitude, property.longitude),
                animation: google.maps.Animation.DROP,
            });

            marker.addListener('click', function () {
                infowindow.setContent('<img src="assets/img/logo.jpg" style="height:50px;width:50px;"><br>'
                    + '<p>Name: ' + property.brandName + '</p>' +
                    '<p>Latitude: ' + property.modelName + '</p>' +
                    '<p>Longitude: ' + property.price + '</p>' +
                    `<button type="button" color="primary" onclick="window.angularComponentRef.zone.run(() => {window.angularComponentRef.component.goToPropertyDetail(` + property.productId + `);})">` + `Show More</button>`);
                infowindow.open(this.map, marker);
                this.map.setCenter(marker.position);
            });

            // google.maps.event.trigger(marker, 'click');
            marker.setMap(this.usermap);

        }
    }

    goToPropertyDetail(id) {

        if (this.loggedInUser == undefined || this.loggedInUser == null || this.loggedInUser == "") {
            this.presentToast("Only registered user can view the details. Please sign up.");
            //this.navCtrl.popToRoot();
        } else {
            console.log(this.loggedInUser.access_token);
            this.dataService.searchOneProperty(this.loggedInUser.access_token, id)
                .subscribe(response => {
                    this.dataService.setProperty(response);
                    this.navCtrl.push(PropertyDetailPage);
                },
                error => {
                    console.log("Server Error !" + error);
                });
        }
    }

    locateMe() {

        let loader = this.loading.create({
            content: 'Loading map...',
            dismissOnPageChange: true
        });
        loader.present().then(() => {
            this.geolocation.getCurrentPosition().then((resp) => {
                this.currentLatitude = resp.coords.latitude;
                this.currentLongitude = resp.coords.longitude;
                let myOptions = {
                    zoom: 12,
                    center: new google.maps.LatLng(this.currentLatitude, this.currentLongitude),
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    setMyLocationEnabled: true,
                    animation: google.maps.Animation.BOUNCE
                };

                this.usermap = new google.maps.Map(document.getElementById("usermap"), myOptions);
                let contentString = `<div><img src="assets/img/logo.jpg" style="height:50px;width:50px;">
                                        <p>You are here !</p><div>`;
                let infowindow = new google.maps.InfoWindow({
                    content: contentString
                });

                let marker = new google.maps.Marker({
                    position: new google.maps.LatLng(this.currentLatitude, this.currentLongitude),
                    draggable: true
                });

                marker.addListener('click', function () {
                    infowindow.open(this.usermap, marker);
                });
                marker.setMap(this.usermap);

                let cityCircle = new google.maps.Circle({
                    strokeColor: '#D68910',
                    strokeOpacity: 0.8,
                    strokeWeight: 2,
                    fillColor: '#5DADE2',
                    fillOpacity: 0.35,
                    map: this.usermap,
                    center: new google.maps.LatLng(this.currentLatitude, this.currentLongitude),
                    radius: this.circleRadius,
                    draggable: true,
                    editable: true
                });

                //this.refreshNearByProducts(this.currentLatitude, this.currentLongitude, this.circleRadius);
                loader.dismiss();
                if (this.dataService.getPropertyForMap() != null) {
                    this.getTheNearByProperties();
                }

                cityCircle.addListener('radius_changed', (event) => {
                    this.refreshNearByProducts(cityCircle.getCenter().lat(), cityCircle.getCenter().lng(), cityCircle.getRadius());
                });

                cityCircle.setMap(this.usermap);

                google.maps.event.addListener(this.usermap, 'click', (event) => {
                    cityCircle.setCenter(new google.maps.LatLng(event.latLng.lat(), event.latLng.lng()));
                    this.refreshNearByProducts(event.latLng.lat(), event.latLng.lng(), cityCircle.getRadius());
                });

                marker.addListener('drag', (event) => {
                    cityCircle.setOptions({ center: { lat: event.latLng.lat(), lng: event.latLng.lng() } });
                    this.refreshNearByProducts(event.latLng.lat(), event.latLng.lng(), cityCircle.getRadius());
                });

            }).catch((error) => {
                console.log('Error getting location' + error);
                loader.dismiss();
            });
        });

    }

    goBack() {
        this.navCtrl.pop();
    }

}
