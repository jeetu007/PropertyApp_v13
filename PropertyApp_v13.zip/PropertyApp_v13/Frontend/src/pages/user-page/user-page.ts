import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';
import { DataService } from '../../service/service';
import { PropertyDetailPage } from '../property-detail/property-detail';
import { UserMap } from '../user-map/user-map';
import { LoadingController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { PopoverController } from 'ionic-angular';
import { PopupMenu } from '../pop-up/pop-up';
import { AppConfig } from '../../service/app-config';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';


@Component({
  selector: 'page-user',
  templateUrl: 'user-page.html'
})
export class UserPage {


  showList: boolean;
  public access_token: any;
  public userRole: any;
  propertyList: any;
  currentUsername: any;
  public loggedInUser: any;
  public imageUrl: any;
  public imageLogo: any;
  currentLatitude: any;
  currentLongitude: any;


  pageNumber: number = 1;
  pageSize: number = 5;
  showSearch: boolean;
  showNavbar: boolean;
  public userTable: any;
  public isNetworkConnected: boolean;
  searchText: any;



  constructor(private dataService: DataService, public navCtrl: NavController, public navParam: NavParams,
    public loading: LoadingController, private toastCtrl: ToastController, public appConfig: AppConfig,
    private geolocation: Geolocation, public popoverCtrl: PopoverController, private sqlite: SQLite) {
  }

  presentToast(mesg) {
    let toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  keyUpFun() {
    if (this.searchText.length > 0) {
      document.getElementById('clearBtn').style.display = "block";
    } else {
      document.getElementById('clearBtn').style.display = "none";
    }
  }

  clear() {
    this.searchText = "";
    document.getElementById('clearBtn').style.display = "none";
    
  }

  public staticPanel: boolean = false;

  presentPopover(myEvent) {
    this.staticPanel = true;
  }
  /*this method is used to hide the home navbar with the search navbar when search button is clicked*/
  searchButton() {
    this.showSearch = true;
    this.showNavbar = false;
  }

  closeWindow() {
    this.staticPanel = false;
  }

  //Back button 
  back(event) {
    event.preventDefault();
    this.showSearch = false;
    this.showNavbar = true;
    this.getProperties();
  }

  ionViewDidEnter() {

  }

  /*This method loads at the page loading time and gets all the registered products*/
  ionViewDidLoad() {
    this.isNetworkConnected = this.appConfig.checkNetworkConnection();
    if (!this.isNetworkConnected) {
      this.presentToast("No network detected. Please connect to a network to continue.");
      this.navCtrl.popToRoot();
    }
    this.showSearch = false;
    this.showNavbar = true;
    this.imageUrl = this.appConfig.getGoogleCouldImageUrl();
    this.imageLogo = this.appConfig.getDefaultImageLogo();
    this.userTable = this.appConfig.getUserTableName();

    //--------
    this.dataService.getCurrentUser().then((resp) => {
      console.log("UserPage-" + JSON.stringify(resp));
      this.loggedInUser = resp;
      this.currentUsername = this.loggedInUser.user;
    }).catch((error) => {
      console.log(error);
    });
    let loader = this.loading.create({
      content: 'Loading Data..',
    });
    loader.present().then(() => {
      this.geolocation.getCurrentPosition().then((resp) => {
        this.currentLatitude = resp.coords.latitude;
        this.currentLongitude = resp.coords.longitude;
        this.getProperties();
        loader.dismiss();

      }).catch((error) => {
        this.presentToast("Something went wrong !!");
        console.log(error);
        loader.dismiss();
      });
    });
    //----------
  }

  /**
    * This method is used to fetch the properties along with pagination.
    * 
    */
  getProperties() {
    this.pageNumber = 1;
    let loader = this.loading.create({
      content: 'Loading...',
    });
    loader.present().then(() => {
      this.dataService.getProperties(this.loggedInUser.access_token, this.loggedInUser.authorities, this.loggedInUser.username, this.currentLatitude, this.currentLongitude, this.pageNumber, this.pageSize)
        .subscribe(
        (response) => {
          this.propertyList = [];
          this.propertyList = response;
          loader.dismiss();
          console.log("response data below - ");
          console.log(this.propertyList);
          //this.propertyList.push(response);
        },
        (error) => {
          console.log("ProductPageError--" + error);
          if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
            console.log("Access Token Expired.");
            this.validateRefreshToken(this.loggedInUser.refresh_token);
            this.getProperties();
          } else {
            loader.dismiss();
            this.presentToast("Something went wrong. Try again.");
            console.log(error);
            this.navCtrl.popToRoot();
          }
        }
        );
    });
  }


  /**
 * This method is used whenever the access token gets expired. 
 * This method refreshes the logged in user tokens using the refresh token.
 * This method also validates whether the refresh token is alive or expired.
 * @param refresh_token 
 * @author Premnath Christopher
 */
  validateRefreshToken(refresh_token) {
    this.dataService.validateRefreshToken(refresh_token).subscribe(
      (res) => {
        this.dataService.setCurrentUser(res, this.loggedInUser.username);
        console.log("Using Refresh Token - " + JSON.stringify(res));
        this.loggedInUser = res;
        this.currentUsername = this.loggedInUser.user;
      }, (err) => {
        console.log(err);
        this.presentToast("Your session has been expired. Please login again.");
        this.navCtrl.popToRoot();
      }
    );
  }

  /**
   * This method is used to search one property on the map.
   * @param value 
     @author Premnath Christopher
   */
  searchProperty(value) {
    let loader = this.loading.create({
      content: 'Searching...',
    });
    loader.present().then(() => {
      this.dataService.searchProperty(value)
        .subscribe((value) => {
          if (value == null) {
            loader.dismiss();
            this.presentToast('The Property does not exist!');
          } else {
            console.log(value);
            this.propertyList = [];
            this.propertyList = value;
            loader.dismiss();
          }
        },
        (error) => {
          if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
            console.log("Access Token Expired.");
            this.validateRefreshToken(this.loggedInUser.refresh_token);
            this.searchProperty(value);
          }
          this.presentToast(value + ' deoes not exist at the moment.');
          loader.dismiss();
        }
        );
    });
  }

  /*This method is used to see the property details. The navcontroller goes to the ProductDetailPage*/
  checkPropertyDetail(property: any) {
    this.navCtrl.push(PropertyDetailPage, { "propertyDetail": property });
    console.log("PropId- " + property.productId);
  }

  /*This method is used to see all the products that are nearby to the device's location on google map*/
  showPropertyOnMap() {
    this.dataService.setPropertyForMap(this.propertyList);
    this.navCtrl.push(UserMap);
  }

  //----
  /**
  * This is for pagination while scroling.
  * Author: Darshan mkwn
  * */

  doInfinite(infiniteScroll) {

    this.pageNumber += 1;
    console.log("Scroll Page number - " + this.pageNumber);

    this.dataService.getProperties(this.loggedInUser.access_token, this.loggedInUser.authorities,
      this.loggedInUser.username, this.currentLatitude, this.currentLongitude, this.pageNumber, this.pageSize)
      .subscribe(
      (response) => {
        console.log(response);
        if (response === null || response === undefined || response === " ") {
          console.log("No content found");
          infiniteScroll.complete();
        } else {
          console.log("Else Part..");
          for (let index in response) {
            console.log(response[index]);
            this.propertyList.push(response[index]);
          }
          console.log(this.propertyList);
          infiniteScroll.complete();
        }
      },
      (error) => {
        if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
          console.log("Unauthorized.");
          console.log("Access Token Expired.");
        }
        infiniteScroll.enable(false);
        console.log(error);
      }
      );

  }//end doinfinite
  //----

  /** This method is used to show a pop over menu on the menubar
   *   @auhtor Vinod Khuswah
   */

  logout() {
    this.staticPanel = false;
    console.log(this.loggedInUser.access_token);
    let query = "DELETE FROM " + this.userTable;
    this.sqlite.create({
      name: 'data.db',
      location: 'default'
    })
      .then((db: SQLiteObject) => {

        db.executeSql(query, {})
          .then((data) => console.log('Executed SQL.Data Deleted.' + data.rows.length))
          .catch(e => console.log('Error.' + e));

      })
      .catch(e => console.log(e));
    // Remove API token 
    this.dataService.logout(this.loggedInUser.access_token)
      .subscribe(
      response => {
        let toast = this.toastCtrl.create({
          message: response,
          duration: 3000,
          position: 'top'
        });
        this.loggedInUser = [];
        toast.present();
        this.navCtrl.popToRoot();
      },
      (error) => {
        console.log("Server Error !" + error);
        if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
          console.log("Unauthorized.");
          this.presentToast("Your session has been expired. Please login.");
          this.navCtrl.popToRoot();
        } else {
          this.presentToast("Something went wrong. Try again.");
          console.log(error);
          this.navCtrl.popToRoot();
        }
      }
      );
    this.navCtrl.popToRoot();
  }

}
