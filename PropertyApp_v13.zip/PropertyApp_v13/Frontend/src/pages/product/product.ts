import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { File, FileEntry } from '@ionic-native/file';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Geolocation } from '@ionic-native/geolocation';
import { DataService } from '../../service/service';
import { PropertyDetailPage } from '../property-detail/property-detail';
import { UserMap } from '../user-map/user-map';
import { PopupMenu } from '../pop-up/pop-up';
import { LoadingController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { UUID } from 'angular2-uuid';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { ImageResizer, ImageResizerOptions } from '@ionic-native/image-resizer';
import { ImagePicker } from '@ionic-native/image-picker';
import { AlertController } from 'ionic-angular';
import { UploadStatus } from '../upload-status/upload-status';
import { Events } from 'ionic-angular';
import { PopoverController } from 'ionic-angular';
import { AppConfig } from '../../service/app-config';


@Component({
  selector: 'page-product',
  templateUrl: 'product.html',

})
export class ProductPage {
  appType: string;
  doRegistration: boolean = false;
  checkProperty: boolean = true;
  cameraClick: boolean = false;
  userForm: FormGroup;
  propertyData: any;
  currentLatitude: any;
  currentLongitude: any;
  formData: FormData;
  propertyImage: any;
  propertyList: any = [];
  userRole: any;
  propertyImagesList: any;
  currentUsername: any;
  propertyImageName: any;
  PropertyCloudImageUrl: any;
  PropertyCloudImageUrlList: any = [];
  public loggedInUser: any;
  public imageUrl: any;
  public imageLogo: any;

  pageNumber: number = 1;
  pageSize: number = 5;
  imageBlobList: any = [];
  thumbnilBlobList: any = [];
  propertyThumbnilName: any;
  PropertyCloudThumbnilUrlList: any = [];
  thumbnilPropertyImageDisplay: any = [];
  propertiesToBeDeleted: any;
  showSearch: boolean;
  showNavbar: boolean;

  public userTable: any;
  public imageTable: any;
  public isNetworkConnected: boolean;
  public searchText:any;
  


  constructor(public navCtrl: NavController, public file: File, public camera: Camera, private formBuilder: FormBuilder,
    private geolocation: Geolocation, private dataService: DataService, public navParam: NavParams,
    public loading: LoadingController, private toastCtrl: ToastController, private sqlite: SQLite,
    private imageResizer: ImageResizer, private appConfig: AppConfig,
    private imagePicker: ImagePicker, public alertCtrl: AlertController, public events: Events, public popoverCtrl: PopoverController) {

    this.userForm = this.formBuilder.group({
      brandName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      modelName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      locationTag: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      price: ['', Validators.compose([Validators.minLength(5), Validators.maxLength(10), Validators.pattern('[0-9]*'), Validators.required])],
      width: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(10), Validators.pattern('[0-9]*'), Validators.required])],
      height: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.required])],
      remark: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      attributeName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      attributeDisplayName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      attributeValue: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])]
    });

  }


  /*this method is used to hide the home navbar with the search navbar when search button is clicked*/
  searchButton() {
    this.showSearch = true;
    this.showNavbar = false;
  }

  //Back button 
  back(event) {
    event.preventDefault();
    this.showSearch = false;
    this.showNavbar = true;
    this.getProperties();
  }

  closeWindow() {
    this.staticPanel = false;
  }

  keyUpFun() {
    if (this.searchText.length > 0) {
      document.getElementById('clearBtn').style.display = "block";
    } else {
      document.getElementById('clearBtn').style.display = "none";
    }
  }

  clear() {
    this.searchText = "";
    document.getElementById('clearBtn').style.display = "none";
    
  }

  /** This method is used to show a pop over menu on the menubar
   *   @auhtor Vinod Khuswah
   */
  public staticPanel: boolean = false;

  presentPopover(myEvent) {
    this.staticPanel = true;
  }

  /**
   * This method gets the current location as well as the current logged in user information.
   * It also fetches the property list to display on home page.
   * @author Premnath Christopher
   */
  ionViewDidEnter() {

    if (this.appType === "eye") {
      this.appType = "eye";
      this.checkProperty = true;
      this.doRegistration = false;
    } else {
      this.appType = "list-box";
      this.doRegistration = true;
      this.checkProperty = false;
    }
    this.imageUrl = this.appConfig.getGoogleCouldImageUrl();
    this.imageLogo = this.appConfig.getDefaultImageLogo();

    this.geolocation.getCurrentPosition().then((resp) => {
      this.currentLatitude = resp.coords.latitude;
      this.currentLongitude = resp.coords.longitude;
    }).catch((error) => {
      console.log('Error getting location' + error);
    });
    this.dataService.getCurrentUser().then((resp) => {
      console.log("ProductPage-" + JSON.stringify(resp));
      this.loggedInUser = resp;
      this.currentUsername = this.loggedInUser.user;
      this.getProperties();
    }).catch((error) => {
      console.log(error);
    });

  }//end ionViewDidEnter


  ionViewDidLoad() {
    this.isNetworkConnected = this.appConfig.checkNetworkConnection();
    if (!this.isNetworkConnected) {
      this.presentToast("No Network");
    }
    if (this.appType === "eye") {
      this.appType = "eye";
      this.checkProperty = true;
      this.doRegistration = false;
    } else {
      this.appType = "list-box";
      this.doRegistration = true;
      this.checkProperty = false;
    }
    this.imageTable = this.appConfig.getImageTableName();
    this.userTable = this.appConfig.getUserTableName();
    this.isNetworkConnected = this.appConfig.checkNetworkConnection();
    this.showSearch = false;
    this.showNavbar = true;
    this.formData = new FormData();
    this.propertyImagesList = [];
    this.PropertyCloudImageUrl = this.appConfig.getGoogleCouldImageUrl();

  }//end ionViewDidLoad()


  /**
   * Toggle between the registration and view property segments
   * @author Premnath Christopher
   */
  registerProperty() {
    this.doRegistration = true;
    this.checkProperty = false;
  }


  /******************************* Start by Darshan ***********************************/

  presentToast(mesg) {
    let toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  /**
   * Toggle between the registration and list segments.
   * 
   */
  viewProperty() {
    this.checkProperty = true;
    this.doRegistration = false;
    this.getProperties();
  }

  /**
   * This method is used to fetch the properties along with pagination.
   * 
   */
  getProperties() {
    this.pageNumber = 1;

    let loader = this.loading.create({
      content: 'Please wait..',
    });
    loader.present().then(() => {
      this.dataService.getProperties(this.loggedInUser.access_token, this.loggedInUser.authorities, this.loggedInUser.username, this.currentLatitude, this.currentLongitude, this.pageNumber, this.pageSize)
        .subscribe(
        (response) => {
          this.propertyList = [];
          this.propertyList = response;
          loader.dismiss();
          console.log("response data below - ");
          console.log(this.propertyList);
          //this.propertyList.push(response);
        },
        (error) => {
          console.log("ProductPageError--" + error);
          if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
            console.log("Access Token Expired.");
            this.validateRefreshToken(this.loggedInUser.refresh_token);
            this.getProperties();
          } else {
            loader.dismiss();
            this.presentToast("Something went wrong. Try again.");
            console.log(error);
            this.navCtrl.popToRoot();
          }
        }
        );
    });
  }

  /**
   * This method is used whenever the access token gets expired. 
   * This method refreshes the logged in user tokens using the refresh token.
   * This method also validates whether the refresh token is alive or expired.
   * @param refresh_token 
   * @author Premnath Christopher
   */
  validateRefreshToken(refresh_token) {
    this.dataService.validateRefreshToken(refresh_token).subscribe(
      (res) => {
        this.dataService.setCurrentUser(res, this.loggedInUser.username);
        console.log("Using Refresh Token - " + JSON.stringify(res));
        this.loggedInUser = res;
        this.currentUsername = this.loggedInUser.user;
      }, (err) => {
        console.log(err);
        this.presentToast("Your session has been expired. Please login again.");
        this.navCtrl.popToRoot();
      }
    );
  }

  /**
   * This method is used to refresh the contents on the page.
   * 
   * @param refresher 
   * @author Premnath Christopher
   */
  doRefresh(refresher) {
    console.log('Begin async operation', refresher);

    setTimeout(() => {
      console.log('Async operation has ended');
      this.getProperties();
      refresher.complete();
    }, 2000);
  }

  /**
   * This method uses the ImagePicker cordova plugin to select multiple images at once.
   * @param event 
   * @author Premnath Christopher
   */
  addImages(event) {
    event.preventDefault();
    this.cameraClick = true;
    let options = {
      // max images to be selected, defaults to 15. If this is set to 1, upon
      // selection of a single image, the plugin will return it.
      maximumImagesCount: 15,

      // max width and height to allow the images to be.  Will keep aspect
      // ratio no matter what.  So if both are 800, the returned image
      // will be at most 800 pixels wide and 800 pixels tall.  If the width is
      // 800 and height 0 the image will be 800 pixels wide if the source
      // is at least that wide.
      width: 3006,
      height: 5344,

      // quality of resized image, defaults to 100
      quality: 100
    };
    this.imagePicker.getPictures(options).then((results) => {
      for (let i = 0; i < results.length; i++) {
        console.log('Image URI: ' + results[i]);
        this.propertyImage = results[i];
        this.propertyImagesList.push(this.propertyImage);
        this.file.resolveLocalFilesystemUrl(results[i])
          .then(entry => (<FileEntry>entry).file(file => { this.readImageFile(file, results[i], "original"); this.imageResizerthumbnail(results[i]); }))
          .catch(err => console.log(err));
      }
    }, (err) => {
      this.presentToast("Something went wrong in ImagePicker !!");
    });
  }

  /**
   * This method is used for the camera functionality
   * @param event 
   */
  takePicture(event) {
    event.preventDefault();
    let toast = this.toastCtrl.create({
      message: 'Sorry ! please try again.!',
      duration: 2000,
      position: 'top'
    });
    this.cameraClick = true;
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      saveToPhotoAlbum: true
    }
    this.camera.getPicture(options).then((imageData) => {
      this.propertyImage = imageData;
      this.propertyImagesList.push(this.propertyImage);
      this.file.resolveLocalFilesystemUrl(imageData)
        .then(entry => (<FileEntry>entry).file(file => { this.readImageFile(file, imageData, "original"); this.imageResizerthumbnail(imageData); }))
        .catch(err => console.log(err));
    }, (err) => {
      toast.present();
    });
  }


  //for uploading image path and thumbnail path on sqlite.
  imagePathForSQLite(uuidname, filepath) {

    this.sqlite.create({
      name: 'data.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
      db.executeSql('INSERT INTO ' + this.imageTable + ' (name,path,status) VALUES(?,?,?)', [uuidname, filepath, "pending"])
        .then(() => console.log('image data is inserted ..............'))
        .catch(e => { console.log('image data is not inserted ..............'); console.log(e) });
    }).catch(e => console.log('image data is not inserted ..............'));

  }

  /**
   * This method is used to read the captured images and creates a list of two images,i.e thumbail and original image.
   * Both the original image and thumbail are then inserted into SQL Lite as well as in an array.
   * These two sets are then used for uploading. 
   * @param file 
   * @param filepath 
   * @param propertyName 
   * @author Premnath Christopher
   */
  readImageFile(file: any, filepath, propertyName: any) {
    const reader = new FileReader();
    reader.onloadend = () => {
      let imageBlob = new Blob([reader.result], { type: file.type });

      if (propertyName != "thumbnail") {
        let uuid = UUID.UUID();
        this.propertyImageName = "property-" + uuid + ".jpg";
        //list of images as blob
        this.imageBlobList.push(imageBlob);
        //list of cloud image url.
        this.PropertyCloudImageUrlList.push(this.propertyImageName);
        //this is for storing data into sqlite
        this.imagePathForSQLite(this.propertyImageName, filepath);
        localStorage.setItem(this.propertyImageName, filepath);  
      } else {
        //list of thubnail image 
        this.thumbnilBlobList.push(imageBlob);
        let uuid = UUID.UUID();
        this.propertyThumbnilName = "propertythumbnail-" + uuid + ".jpg";
        //this is for containing thumbnail url image list.
        this.PropertyCloudThumbnilUrlList.push(this.propertyThumbnilName);
        //this is for storing data into sqlite
        this.imagePathForSQLite(this.propertyThumbnilName, filepath);
        localStorage.setItem(this.propertyThumbnilName, filepath);  
      }
    };
    reader.readAsArrayBuffer(file);
  }//end readImageFile()

  /**
   * This method is used to resize the original image for generating thumbnail.
   * @param uri 
   * @author Darshan 
   */
  imageResizerthumbnail(uri) {
    let options = {
      uri: uri,
      folderName: 'Protonet',
      quality: 90,
      width: 500,
      height: 500
    } as ImageResizerOptions;

    this.imageResizer
      .resize(options)
      .then((filePath: string) => {

        this.thumbnilPropertyImageDisplay.push(filePath);
        this.file.resolveLocalFilesystemUrl(filePath)
          .then(entry => (<FileEntry>entry).file(file => {
            this.readImageFile(file, filePath, "thumbnail");
          }
          ))
          .catch(err => console.log(err));
      })
      .catch(e => console.log(e));
  }//end iamgeResizerThumbnail()


  /**
   * This method is used to create a new property.
   * @author Premnath Christopher
   */
  uploadData() {
    this.events.publish('upload', 'upload');
    this.propertyData = [
      {
        "brandName": this.userForm.value.brandName,
        "modelName": this.userForm.value.modelName,
        "locationTag": this.userForm.value.locationTag,
        "price": this.userForm.value.price,
        "width": this.userForm.value.width,
        "height": this.userForm.value.height,
        "latitude": this.currentLatitude,
        "longitude": this.currentLongitude,
        "remark": this.userForm.value.remark,
        "lastModifiedUser": {
          "userId": 1
        },
        "extraAttributeList": [
          {
            "attributeName": this.userForm.value.attributeName,
            "attributeDisplayName": this.userForm.value.attributeDisplayName,
            "attributeValue": this.userForm.value.attributeValue
          }
        ],
        "imageUrlList": this.PropertyCloudImageUrlList,
        "shortImageUrlList": this.PropertyCloudThumbnilUrlList
      }
    ]

    /********************* For register peorudct ***********************/
    //for testing service registration...
    let loader = this.loading.create({
      content: 'Please wait..',
    });
    loader.present().then(() => {
      this.dataService.doPropertyRegistration(this.propertyData,
        this.loggedInUser.access_token, this.loggedInUser.username)
        .subscribe(
        (res) => {
          this.userForm.reset();
          this.formData = new FormData();
          this.thumbnilPropertyImageDisplay = [];
          this.propertyData = [];
          this.PropertyCloudImageUrlList = [];
          this.imageBlobList = [];
          this.thumbnilBlobList = [];
          this.PropertyCloudThumbnilUrlList = [];
          loader.dismiss();
          this.presentToast("Property data registered successfully !!");
        }, (error) => {
          if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
            console.log("Access Token Expired.");
            this.validateRefreshToken(this.loggedInUser.refresh_token);
            this.uploadData();
          }
          loader.dismiss();
          this.presentToast("Something went wrong.Try Again.");
        }
        );
    });

    /*******************************************************************/
  }//end uploadData


  /**
  * This is for pagination while scroling.
  * Author: Darshan mkwn
  * */

  doInfinite(infiniteScroll) {

    this.pageNumber += 1;
    console.log("Scroll Page number - " + this.pageNumber);

    this.dataService.getProperties(this.loggedInUser.access_token, this.loggedInUser.authorities,
      this.loggedInUser.username, this.currentLatitude, this.currentLongitude, this.pageNumber, this.pageSize)
      .subscribe(
      (response) => {
        console.log(response);
        if (response === null || response === undefined || response === " ") {
          console.log("No content found");
          infiniteScroll.complete();
        } else {
          console.log("Else Part..");
          for (let index in response) {
            console.log(response[index]);
            this.propertyList.push(response[index]);
          }
          console.log(this.propertyList);
          infiniteScroll.complete();
        }
      },
      (error) => {
        if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
          console.log("Unauthorized.");
          console.log("Access Token Expired.");
        }
        infiniteScroll.enable(false);
        console.log(error);
      }
      );

  }//end doinfinite


  /******************************* end ***********************************/

  /**This method is used to confirm the delete functionality. */
  showDeleteConfirmation(property) {
    let confirm = this.alertCtrl.create({
      title: 'Are you sure to delete ?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Yes',
          handler: () => {
            console.log('Agree clicked');
            this.deleteProperty(property);
          }
        }
      ]
    });
    confirm.present();
  }

  /**
   * This method is used to remove the already selected image from SQL Lite
   * @param propertyImage 
   * @author Premnath Christopher
   */
 removePropertyImage(propertyImage) {
    console.log("Image to be Removed ==> " + propertyImage);
    const index: number = this.thumbnilPropertyImageDisplay.indexOf(propertyImage);
    if (index !== -1) {
      this.thumbnilPropertyImageDisplay.splice(index, 1);
    }

    for (var i = 0; i < localStorage.length; i++) {
      var key = localStorage.key(i);
      var filepath = localStorage.getItem(key);
      console.log(key + " |-:-| " + filepath);
      //---
      let query = "DELETE FROM " + this.imageTable + " WHERE path = '" + filepath + "'";
      this.sqlite.create({
        name: 'data.db',
        location: 'default'
      })
        .then((db: SQLiteObject) => {
          db.executeSql(query, {})
            .then((data) => {
              console.log('Executed SQL...Data Deleted...' + data.rows.length);
            })
            .catch(e => console.log('Error.' + JSON.stringify(e)));
        })
        .catch(e => console.log(JSON.stringify(e)));
      //---
    }
  }

  /**
   * This method is used to delete one property from the backend.
   * Both access token and refresh token are being checked for validation and after validation only, it will be deleted.
   * @param property 
   * @author Premnath Christopher
   */
  deleteProperty(property: any) {
    this.propertiesToBeDeleted = [];
    this.propertiesToBeDeleted.push(property);
    let loader = this.loading.create({
      content: 'Deleting...',
    });
    loader.present().then(() => {
      this.dataService.deleteProducts(this.loggedInUser.access_token, this.propertiesToBeDeleted)
        .subscribe(
        response => {
          console.log(response);
          if (response == 200 || response === 200) {
            this.presentToast("Property data deleted successfully !!");
            loader.dismiss();
          } else {
            this.presentToast("Something went wrong!");
            loader.dismiss();
          }
          this.refreshPropertyList(property);
        },
        error => {
          if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
            console.log("Access Token Expired.");
            this.validateRefreshToken(this.loggedInUser.refresh_token);
            this.deleteProperty(property);
          }
          console.log(error);
          this.presentToast("Something went wrong. Please try again!");
          loader.dismiss();
        }
        );
    });

  }

  /**
   * This method is used to refresh the property list in the view after deletion of one property.
   * @param property 
   * @author Premnath Christopher
   */
  refreshPropertyList(property) {
    const index: number = this.propertyList.indexOf(property);
    if (index !== -1) {
      this.propertyList.splice(index, 1);
    }
  }



  /**
   * This method is used to view the details of the selected property on a different page.
   * @param property 
   * @author Premnath Christopher
   */
  checkPropertyDetail(property: any) {
    this.navCtrl.push(PropertyDetailPage, { "propertyDetail": property });
    console.log("PropId- " + property.productId);
  }

  /**
   * This method is used to display the properties on the map.
   */
  showPropertyOnMap() {
    this.dataService.setPropertyForMap(this.propertyList);
    this.navCtrl.push(UserMap);
  }

  /**
   * This method is used to search one property on the map.
   * @param value 
     @author Premnath Christopher
   */
  searchProperty(value) {
    this.appType = 'eye';
    this.checkProperty = true;
    this.doRegistration = false;
    let loader = this.loading.create({
      content: 'Searching...',
    });
    loader.present().then(() => {
      this.dataService.searchProperty(value)
        .subscribe((value) => {
          if (value == null) {
            this.presentToast('The Property does not exist!');
            loader.dismiss();  
          } else {
            console.log(value);
            this.propertyList = [];
            this.propertyList = value;
            loader.dismiss();
          }
        },
        (error) => {
          if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
            console.log("Access Token Expired.");
            this.validateRefreshToken(this.loggedInUser.refresh_token);
            this.searchProperty(value);
          }
          loader.dismiss();
          this.presentToast(value + ' deoes not exist at the moment.');
        }
        );
    });
  }

  /**
 * This method is used to check the upload status of the captured images.
 * @param event 
 * @author Vinod Kushwah
 */
  checkUploadstatus(event) {
    this.staticPanel = false;
    event.preventDefault();
    this.navCtrl.push(UploadStatus);
  }

  logout() {
    this.staticPanel = false;
    console.log(this.loggedInUser.access_token);
    let query = "DELETE FROM " + this.userTable;
    this.sqlite.create({
      name: 'data.db',
      location: 'default'
    })
      .then((db: SQLiteObject) => {

        db.executeSql(query, {})
          .then((data) => console.log('Executed SQL.Data Deleted.' + data.rows.length))
          .catch(e => console.log('Error.' + e));

      })
      .catch(e => console.log(e));
    // Remove API token 
    this.dataService.logout(this.loggedInUser.access_token)
      .subscribe(
      response => {
        let toast = this.toastCtrl.create({
          message: response,
          duration: 3000,
          position: 'top'
        });
        this.loggedInUser = [];
        toast.present();
        this.navCtrl.popToRoot();
      },
      (error) => {
        console.log("Server Error !" + error);
        if (error === "401 - Unauthorized" || error == "401 - Unauthorized") {
          console.log("Unauthorized.");
          this.presentToast("Your session has been expired. Please login.");
          this.navCtrl.popToRoot();
        } else {
          this.presentToast("Something went wrong. Try again.");
          console.log(error);
          this.navCtrl.popToRoot();
        }
      }
      );
    this.navCtrl.popToRoot();
  }


}
