import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { ProductPage } from '../pages/product/product';
import { PropertyDetailPage } from '../pages/property-detail/property-detail';

import { UserRegistrationPage } from '../pages/user-registration/user-registration';
import { UserPage } from '../pages/user-page/user-page';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { File } from '@ionic-native/file';
import { Camera } from '@ionic-native/camera';
import { FormsModule }   from '@angular/forms';
import { ToastController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { DataService } from '../service/service';
import { AppConfig } from '../service/app-config';
import { HttpModule } from '@angular/http';
import { UserMap } from '../pages/user-map/user-map';
import { Welcome } from '../pages/welcome/welcome';
import { UploadStatus } from '../pages/upload-status/upload-status';
import { GuestUserPage } from '../pages/guest-user/guest-user';
import { PopupMenu } from '../pages/pop-up/pop-up';
import { UUID } from 'angular2-uuid';
import { SQLite } from '@ionic-native/sqlite';
import { ImageResizer } from '@ionic-native/image-resizer';
import { BackgroundMode } from '@ionic-native/background-mode';
import { BackgroundServices } from '../service/backgroundservices';
import { ImagePicker } from '@ionic-native/image-picker';
import { SearchFilterPipe } from '../pipes/search-filter/search-filter';
import { IonicStorageModule } from '@ionic/storage';
import { Network } from '@ionic-native/network';



@NgModule({
  declarations: [
    MyApp,
    ProductPage,
    PropertyDetailPage,
    UserRegistrationPage,
    UserMap,
    Welcome,
    Welcome,
    GuestUserPage,
    PopupMenu,
    UserPage,
    UploadStatus,
    SearchFilterPipe
  ],
  imports: [
    BrowserModule,FormsModule,HttpModule,
    IonicStorageModule.forRoot(),
    IonicModule.forRoot(MyApp,{tabsPlacement: 'top'})
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    ProductPage,
    PropertyDetailPage,
    UserRegistrationPage,
    UserMap,
    Welcome,
    GuestUserPage,
    PopupMenu,
    UserPage,
    UploadStatus
  ],
  providers: [
    StatusBar,
    SplashScreen,File,Camera,ToastController,Geolocation,DataService,UUID,SQLite,ImageResizer,BackgroundMode,BackgroundServices,
    ImagePicker,Network,AppConfig,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
