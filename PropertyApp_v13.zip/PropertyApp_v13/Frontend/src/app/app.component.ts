import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';

import { Welcome } from '../pages/welcome/welcome';
import { File } from '@ionic-native/file';
import { BackgroundMode } from '@ionic-native/background-mode';
import { BackgroundServices } from '../service/backgroundservices';
import { AppConfig } from '../service/app-config';
import { Network } from '@ionic-native/network';
import { ToastController } from 'ionic-angular';



@Component({
    templateUrl: 'app.html'
})
export class MyApp {
    rootPage: any = Welcome;
    public userTable :any;
    public imageTable :any;
    public propertyFolder :any;
    public userFolder :any;

    presentToast(mesg) {
        let toast = this.toastCtrl.create({
            message: mesg,
            duration: 5000,
            position: 'top'
        });
        toast.present();
    }
    constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen, public file: File,
        private sqlite: SQLite, public backgroundServices: BackgroundServices,
        public backgroundMode: BackgroundMode, private network: Network, private toastCtrl: ToastController, private appConfig : AppConfig) {

        //Get all the configured names.
        this.userTable = this.appConfig.getUserTableName();
        this.imageTable = this.appConfig.getImageTableName();
        this.propertyFolder = this.appConfig.getPropertyFolderName();
        this.userFolder = this.appConfig.getuserFolderName();

        platform.ready().then(() => {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.

            backgroundMode.enable();

            // watch network for a disconnect
            let disconnectSubscription = this.network.onDisconnect().subscribe(() => {
                this.presentToast('Network disconnected.');
                this.appConfig.updateNetworkConnection(false);
            });

            // watch network for a connection
            let connectSubscription = this.network.onConnect().subscribe(() => {
                this.presentToast('Network connected.');
                this.appConfig.updateNetworkConnection(true);
                // We just got a connection but we need to wait briefly
                // before we determine the connection type. Might need to wait.
                // prior to doing any api requests as well.
            });

          

            this.file.createDir(this.file.externalDataDirectory, this.propertyFolder, true)
                .then(result =>
                    console.log("Property Folder created-" +this.propertyFolder)
                )
                .catch(error =>
                    console.log("Error creating directory." + error)
                );
            this.file.createDir(this.file.externalDataDirectory, this.userFolder, true)
                .then(result =>
                    console.log("User Folder created -" +this.userFolder)
                )
                .catch(error =>
                    console.log("Error creating directory." + error)
                );

            //---
            this.sqlite.create({ name: 'data.db', location: 'default' })
                .then((db: SQLiteObject) => {
                    let query = "DELETE FROM "+this.imageTable;
                    db.executeSql(query, {})
                        .then((data) => { console.log("All Records deleted from "+ this.imageTable); })
                        .catch(e => console.log("error- " + e));
                }).catch(e => console.log("error- " + e.code));

            this.sqlite.create({
                name: 'data.db',
                location: 'default'
            })
                .then((db: SQLiteObject) => {


                    db.executeSql('CREATE TABLE IF NOT EXISTS '+this.userTable+' (access_token TEXT,authorities TEXT, expires_in INTEGER, refresh_token TEXT, scope TEXT, token_type TEXT, user TEXT,username TEXT)', {})
                        .then(() => console.log('Executed SQL -'+this.userTable))
                        .catch(e => console.log("error in db creation - " + e));


                })
                .catch(e => console.log(e));

            this.sqlite.create({
                name: 'data.db',
                location: 'default'
            })
                .then((db: SQLiteObject) => {

                    db.executeSql('CREATE TABLE IF NOT EXISTS '+ this.imageTable+' (name TEXT, path TEXT, status TEXT)', {})
                        .then(() => console.log('Executed SQL - '+this.imageTable))
                        .catch(e => console.log(JSON.stringify(e)));


                })
                .catch(e => console.log(e));
            //---
            statusBar.styleDefault();
            splashScreen.hide();
        }).catch((err) => {
            console.log(err);
        });
    }
}